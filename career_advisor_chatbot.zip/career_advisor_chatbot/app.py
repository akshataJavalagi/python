"""
Career Advisor Chatbot - Main Application Entry Point
Production-Ready GenAI Chatbot using Google Gemini API
"""

import streamlit as st
import sys
import os

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))

from src.ui.chat_interface import render_chat_interface
from src.utils.logger import get_logger
from src.utils.config import load_config

logger = get_logger(__name__)


def main():
    """Main application function."""
    # Load configuration
    config = load_config()

    # Page configuration
    st.set_page_config(
        page_title="CareerAI - Your Personal Career Advisor",
        page_icon="🚀",
        layout="wide",
        initial_sidebar_state="expanded",
        menu_items={
            "Get Help": "https://github.com/yourusername/career-advisor-chatbot",
            "Report a bug": "https://github.com/yourusername/career-advisor-chatbot/issues",
            "About": "# CareerAI\nYour Production-Ready Career Advisor Chatbot powered by Google Gemini.",
        },
    )

    logger.info("Application started")

    # Render the main chat interface
    render_chat_interface(config)


if __name__ == "__main__":
    main()
