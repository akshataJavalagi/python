"""
Unit Tests for Career Advisor Chatbot
Tests for session management, prompt engineering, and config validation.
"""

import pytest
from unittest.mock import MagicMock, patch
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.utils.session import SessionManager, ChatMessage
from src.utils.config import AppConfig, GeminiConfig, ChatConfig, validate_config
from src.prompts.career_prompts import CareerAdvisorPrompts


class TestSessionManager:
    """Tests for SessionManager class."""

    def test_init_creates_empty_session(self):
        sm = SessionManager()
        assert sm.is_empty
        assert sm.message_count == 0

    def test_add_message(self):
        sm = SessionManager()
        sm.add_message("user", "Hello")
        assert sm.message_count == 1
        assert not sm.is_empty

    def test_history_trimming(self):
        sm = SessionManager(max_history_turns=2)
        for i in range(10):
            sm.add_message("user", f"Message {i}")
            sm.add_message("model", f"Response {i}")
        # Should keep only last max_history_turns * 2 messages
        assert sm.message_count <= 4

    def test_api_history_format(self):
        sm = SessionManager()
        sm.add_message("user", "Hello")
        sm.add_message("model", "Hi there!")
        sm.add_message("user", "How are you?")
        # Should exclude last message (current input)
        history = sm.get_history_for_api()
        assert len(history) == 2

    def test_clear_history(self):
        sm = SessionManager()
        sm.add_message("user", "Test")
        sm.clear_history()
        assert sm.is_empty

    def test_session_stats(self):
        sm = SessionManager()
        sm.add_message("user", "Test")
        sm.update_token_usage(100)
        stats = sm.get_session_stats()
        assert stats["messages"] == 1
        assert stats["tokens_used"] == 100
        assert stats["api_calls"] == 1


class TestChatMessage:
    """Tests for ChatMessage class."""

    def test_message_creation(self):
        msg = ChatMessage(role="user", content="Test message")
        assert msg.role == "user"
        assert msg.content == "Test message"
        assert msg.message_id is not None

    def test_to_dict_format(self):
        msg = ChatMessage(role="user", content="Hello")
        d = msg.to_dict()
        assert d["role"] == "user"
        assert d["parts"][0]["text"] == "Hello"

    def test_to_display_dict(self):
        msg = ChatMessage(role="assistant", content="Response")
        d = msg.to_display_dict()
        assert "timestamp" in d
        assert "message_id" in d


class TestConfigValidation:
    """Tests for configuration validation."""

    def test_valid_config(self):
        config = AppConfig(
            gemini=GeminiConfig(api_key="test_key_12345")
        )
        is_valid, error = validate_config(config)
        assert is_valid
        assert error is None

    def test_missing_api_key(self):
        config = AppConfig(gemini=GeminiConfig(api_key=""))
        is_valid, error = validate_config(config)
        assert not is_valid
        assert "GEMINI_API_KEY" in error

    def test_invalid_temperature(self):
        config = AppConfig(
            gemini=GeminiConfig(api_key="test_key", temperature=1.5)
        )
        is_valid, error = validate_config(config)
        assert not is_valid

    def test_invalid_max_tokens(self):
        config = AppConfig(
            gemini=GeminiConfig(api_key="test_key", max_output_tokens=99999)
        )
        is_valid, error = validate_config(config)
        assert not is_valid


class TestCareerPrompts:
    """Tests for career prompt engineering."""

    def test_system_prompt_not_empty(self):
        prompt = CareerAdvisorPrompts.get_system_prompt()
        assert len(prompt) > 100

    def test_resume_context_detection(self):
        context = CareerAdvisorPrompts.get_contextual_prompt("Help me fix my resume")
        assert context is not None
        assert "resume" in context.lower() or "Resume" in context

    def test_salary_context_detection(self):
        context = CareerAdvisorPrompts.get_contextual_prompt("I want to negotiate my salary")
        assert context is not None

    def test_no_context_for_general(self):
        context = CareerAdvisorPrompts.get_contextual_prompt("Tell me about career growth")
        assert context is None

    def test_enhanced_message_with_context(self):
        msg = CareerAdvisorPrompts.build_enhanced_user_message("Review my CV please")
        assert len(msg) >= len("Review my CV please")

    def test_error_response_not_empty(self):
        response = CareerAdvisorPrompts.get_error_response()
        assert len(response) > 20


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
