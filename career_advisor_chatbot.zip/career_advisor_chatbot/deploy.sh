#!/bin/bash
# =============================================================
# CareerAI - AWS EC2 Deployment Script
# Run this on your EC2 Ubuntu 22.04 instance
# =============================================================

set -e  # Exit on error

echo "============================================"
echo "  CareerAI - EC2 Deployment Script"
echo "============================================"

# ── 1. System Updates ──────────────────────────
echo "[1/7] Updating system packages..."
sudo apt-get update -y
sudo apt-get upgrade -y

# ── 2. Install Python & pip ────────────────────
echo "[2/7] Installing Python 3.11..."
sudo apt-get install -y python3.11 python3.11-pip python3.11-venv git

# Alias python3 -> python3.11
sudo update-alternatives --install /usr/bin/python3 python3 /usr/bin/python3.11 1

# ── 3. Clone Repository ────────────────────────
echo "[3/7] Cloning repository..."
if [ -d "career_advisor_chatbot" ]; then
    cd career_advisor_chatbot
    git pull origin main
    cd ..
else
    git clone https://github.com/YOUR_USERNAME/career-advisor-chatbot.git career_advisor_chatbot
fi

cd career_advisor_chatbot

# ── 4. Python Virtual Environment ─────────────
echo "[4/7] Setting up virtual environment..."
python3 -m venv venv
source venv/bin/activate

pip install --upgrade pip
pip install -r requirements.txt

# ── 5. Environment Configuration ──────────────
echo "[5/7] Setting up environment variables..."
if [ ! -f ".env" ]; then
    cp .env.example .env
    echo ""
    echo "⚠️  IMPORTANT: Edit .env and add your GEMINI_API_KEY!"
    echo "   Run: nano .env"
    echo "   Then restart this script or run the app manually."
    echo ""
fi

# ── 6. Create logs directory ───────────────────
mkdir -p logs

# ── 7. Launch with nohup (background) ─────────
echo "[6/7] Stopping any existing instances..."
pkill -f "streamlit run app.py" || true
sleep 2

echo "[7/7] Starting CareerAI in background..."
source .env
nohup venv/bin/streamlit run app.py \
    --server.port=8501 \
    --server.address=0.0.0.0 \
    --server.headless=true \
    > logs/streamlit.log 2>&1 &

APP_PID=$!
echo "CareerAI started with PID: $APP_PID"
echo $APP_PID > app.pid

sleep 3

# Check if running
if ps -p $APP_PID > /dev/null; then
    PUBLIC_IP=$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4 2>/dev/null || echo "YOUR_EC2_IP")
    echo ""
    echo "============================================"
    echo "✅ CareerAI is LIVE!"
    echo "   URL: http://$PUBLIC_IP:8501"
    echo "============================================"
    echo ""
    echo "Useful commands:"
    echo "  View logs:   tail -f logs/streamlit.log"
    echo "  Stop app:    kill \$(cat app.pid)"
    echo "  Restart:     bash deploy.sh"
else
    echo "❌ App failed to start. Check logs:"
    cat logs/streamlit.log
fi
