# 🚀 CareerAI — Production-Ready Career Advisor Chatbot

> A production-grade domain-specific chatbot powered by **Google Gemini GenAI API**, built with clean architecture, multi-turn memory, advanced prompt engineering, and deployed on AWS EC2.

![Python](https://img.shields.io/badge/Python-3.11+-blue?logo=python)
![Streamlit](https://img.shields.io/badge/Streamlit-1.35-red?logo=streamlit)
![Gemini](https://img.shields.io/badge/Google_Gemini-1.5_Flash-green?logo=google)
![AWS EC2](https://img.shields.io/badge/AWS-EC2-orange?logo=amazon-aws)

---

## 📋 Table of Contents

1. [Project Overview](#project-overview)
2. [Features](#features)
3. [System Architecture](#system-architecture)
4. [Project Structure](#project-structure)
5. [Local Setup](#local-setup)
6. [Environment Variables](#environment-variables)
7. [Running the App](#running-the-app)
8. [Testing](#testing)
9. [AWS EC2 Deployment](#aws-ec2-deployment)
10. [API Design](#api-design)
11. [Prompt Engineering](#prompt-engineering)

---

## Project Overview

**CareerAI** is a domain-specific chatbot for career guidance. It helps users with:

- 📄 Resume & cover letter writing
- 🎯 Job search strategy & networking
- 💼 Interview preparation (behavioral, technical)
- 💰 Salary negotiation tactics
- 🔄 Career transitions & pivots
- 📈 Career growth & promotion strategies

---

## Features

| Feature | Implementation |
|---|---|
| **Gemini API Integration** | `google-generativeai` SDK with modular client |
| **Multi-Turn Memory** | `SessionManager` class with history trimming |
| **Prompt Engineering** | Role-based system prompts + contextual injection |
| **Error Handling** | Typed exceptions with fallback responses |
| **Secure Config** | `.env` + `python-dotenv`, no hardcoded secrets |
| **Structured Logging** | File + console logging with API call metrics |
| **Clean Architecture** | Separation of API / Prompts / UI / Utils |
| **Interactive UI** | Streamlit dark-theme chat interface |
| **Cloud Deployment** | AWS EC2 with `nohup` background execution |

---

## System Architecture

```
User Browser
     │
     ▼
┌─────────────────────────────────────┐
│         Streamlit UI Layer          │
│   chat_interface.py                 │
│   ├── render_header()               │
│   ├── render_sidebar()              │
│   ├── render_message()              │
│   └── render_suggestion_chips()     │
└────────────────┬────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────┐
│         Backend Layer               │
│   ├── SessionManager (memory)       │
│   ├── AppConfig (config mgmt)       │
│   └── Logger (structured logging)  │
└────────────────┬────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────┐
│     Prompt Engineering Module       │
│   CareerAdvisorPrompts              │
│   ├── SYSTEM_PROMPT (role + rules)  │
│   ├── contextual injection          │
│   └── fallback responses           │
└────────────────┬────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────┐
│         Gemini API Client           │
│   GeminiClient                      │
│   ├── multi-turn chat history       │
│   ├── safety settings               │
│   ├── token usage tracking         │
│   └── typed exception handling     │
└────────────────┬────────────────────┘
                 │
                 ▼
      Google Gemini 1.5 Flash API
```

---

## Project Structure

```
career_advisor_chatbot/
├── app.py                      # Entry point
├── requirements.txt
├── .env.example                # Config template
├── .gitignore
├── deploy.sh                   # EC2 deployment script
├── .streamlit/
│   └── config.toml             # Streamlit theme config
├── src/
│   ├── api/
│   │   └── gemini_client.py    # Gemini API integration
│   ├── prompts/
│   │   └── career_prompts.py   # Prompt engineering
│   ├── ui/
│   │   └── chat_interface.py   # Streamlit UI
│   └── utils/
│       ├── config.py           # Configuration management
│       ├── logger.py           # Structured logging
│       └── session.py          # Session/memory management
├── tests/
│   └── test_core.py            # Unit tests
└── logs/                       # Auto-created at runtime
```

---

## Local Setup

### Prerequisites
- Python 3.11+
- A Google Gemini API key ([Get free key](https://aistudio.google.com/))

### Installation

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/career-advisor-chatbot.git
cd career-advisor-chatbot

# Create and activate virtual environment
python3 -m venv venv
source venv/bin/activate        # Linux/Mac
# venv\Scripts\activate         # Windows

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env and add your GEMINI_API_KEY
```

---

## Environment Variables

| Variable | Required | Default | Description |
|---|---|---|---|
| `GEMINI_API_KEY` | ✅ Yes | — | Google Gemini API key |
| `GEMINI_MODEL` | No | `gemini-1.5-flash` | Model name |
| `GEMINI_MAX_TOKENS` | No | `2048` | Max output tokens |
| `GEMINI_TEMPERATURE` | No | `0.7` | Response creativity (0-1) |
| `MAX_HISTORY_TURNS` | No | `20` | Conversation memory depth |
| `LOG_LEVEL` | No | `INFO` | Logging verbosity |
| `DEBUG_MODE` | No | `false` | Show token usage in UI |

---

## Running the App

```bash
# Activate virtual environment
source venv/bin/activate

# Run locally
streamlit run app.py

# With custom port
streamlit run app.py --server.port 8502
```

App runs at: `http://localhost:8501`

---

## Testing

```bash
# Run all tests
pytest tests/ -v

# With coverage report
pytest tests/ -v --cov=src --cov-report=html

# Run specific test class
pytest tests/test_core.py::TestSessionManager -v
```

---

## AWS EC2 Deployment

### Step 1: Launch EC2 Instance

1. Go to **AWS Console → EC2 → Launch Instance**
2. Choose **Ubuntu Server 22.04 LTS (t2.micro for free tier)**
3. Create/select a key pair (save the `.pem` file)
4. **Security Group** — add inbound rules:
   - SSH (port 22) — Your IP
   - Custom TCP (port 8501) — 0.0.0.0/0 (public access)

### Step 2: Connect to EC2

```bash
chmod 400 your-key.pem
ssh -i your-key.pem ubuntu@YOUR_EC2_PUBLIC_IP
```

### Step 3: Deploy

```bash
# Upload project files
scp -i your-key.pem -r ./career_advisor_chatbot ubuntu@YOUR_EC2_IP:~/

# SSH in and deploy
ssh -i your-key.pem ubuntu@YOUR_EC2_IP
cd career_advisor_chatbot

# Set your API key
nano .env  # Add GEMINI_API_KEY=your_key_here

# Run deployment script
chmod +x deploy.sh
bash deploy.sh
```

### Step 4: Access the App

Visit: `http://YOUR_EC2_PUBLIC_IP:8501`

### EC2 Management Commands

```bash
# View live logs
tail -f logs/streamlit.log

# Stop the app
kill $(cat app.pid)

# Check if running
ps aux | grep streamlit

# Restart
bash deploy.sh
```

---

## API Design

### GeminiClient

```python
client = GeminiClient(config)

# Generate response (multi-turn)
response: APIResponse = client.generate_response(
    user_message="Help me with my resume",
    session=session_manager
)

# APIResponse fields:
# .success    → bool
# .content    → str (response text)
# .input_tokens  → int
# .output_tokens → int
# .duration_ms   → float
# .error_type    → Optional[str]
```

### SessionManager

```python
session = SessionManager(max_history_turns=20)
session.add_message("user", "Hello")
session.add_message("model", "Hi there!")

history = session.get_history_for_api()  # For Gemini API
stats = session.get_session_stats()       # For monitoring
```

---

## Prompt Engineering

CareerAI uses a 3-layer prompt architecture:

1. **System Prompt** — Defines CareerAI's identity, expertise, constraints, and tone
2. **Contextual Injection** — Detects intent keywords (resume, salary, interview) and injects specialist sub-prompts
3. **Conversation History** — Full multi-turn history passed with each API call for context continuity

```python
# Contextual prompt injection
user_message = "Help me negotiate my salary"
# → CareerAdvisorPrompts.SALARY_NEGOTIATION_PROMPT is appended
enhanced = CareerAdvisorPrompts.build_enhanced_user_message(user_message)
```

---

## License

MIT License — free to use, modify, and deploy.
