"""
Gemini API Client Module
Handles all interactions with Google Gemini GenAI API.
Implements modular API logic, error handling, and logging.
"""

import time
from typing import Optional, Generator
from dataclasses import dataclass

import google.generativeai as genai
from google.api_core import exceptions as google_exceptions

from src.utils.config import AppConfig, validate_config
from src.utils.logger import get_logger, log_api_call, log_error
from src.utils.session import SessionManager
from src.prompts.career_prompts import CareerAdvisorPrompts

logger = get_logger(__name__)


@dataclass
class APIResponse:
    """Structured API response object."""
    success: bool
    content: str
    input_tokens: int = 0
    output_tokens: int = 0
    duration_ms: float = 0.0
    error_type: Optional[str] = None
    error_message: Optional[str] = None


class GeminiClient:
    """
    Production-grade Gemini API client.
    Handles API initialization, request formatting, error handling, and logging.
    """

    def __init__(self, config: AppConfig):
        """
        Initialize the Gemini client with application config.

        Args:
            config: Application configuration object.

        Raises:
            ValueError: If API key is missing or invalid.
        """
        self.config = config
        self._model = None
        self._initialized = False
        self._initialize()

    def _initialize(self):
        """Initialize Gemini API connection."""
        is_valid, error_msg = validate_config(self.config)
        if not is_valid:
            logger.error(f"Configuration validation failed: {error_msg}")
            return

        try:
            genai.configure(api_key=self.config.gemini.api_key)

            generation_config = genai.types.GenerationConfig(
                max_output_tokens=self.config.gemini.max_output_tokens,
                temperature=self.config.gemini.temperature,
                top_p=self.config.gemini.top_p,
                top_k=self.config.gemini.top_k,
            )

            safety_settings = [
                {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
                {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
                {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
                {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
            ]

            self._model = genai.GenerativeModel(
                model_name=self.config.gemini.model_name,
                generation_config=generation_config,
                safety_settings=safety_settings,
                system_instruction=CareerAdvisorPrompts.get_system_prompt(),
            )

            self._initialized = True
            logger.info(f"Gemini client initialized with model: {self.config.gemini.model_name}")

        except Exception as e:
            log_error(logger, "INIT_ERROR", str(e))
            self._initialized = False

    @property
    def is_ready(self) -> bool:
        """Check if client is properly initialized."""
        return self._initialized and self._model is not None

    def generate_response(
        self,
        user_message: str,
        session: SessionManager,
    ) -> APIResponse:
        """
        Generate a response for the user message.

        Args:
            user_message: The user's input message.
            session: Current chat session manager.

        Returns:
            APIResponse with content and metadata.
        """
        if not self.is_ready:
            return APIResponse(
                success=False,
                content=CareerAdvisorPrompts.get_error_response(),
                error_type="NOT_INITIALIZED",
                error_message="Gemini client is not initialized. Please check API key.",
            )

        start_time = time.time()

        try:
            # Build conversation history for multi-turn context
            history = session.get_history_for_api()

            # Create chat session with history
            chat = self._model.start_chat(history=history)

            # Optionally enhance message with contextual prompts
            enhanced_message = CareerAdvisorPrompts.build_enhanced_user_message(user_message)

            # Send message and get response
            response = chat.send_message(enhanced_message)

            duration_ms = (time.time() - start_time) * 1000

            # Extract token usage
            input_tokens = 0
            output_tokens = 0
            try:
                input_tokens = response.usage_metadata.prompt_token_count or 0
                output_tokens = response.usage_metadata.candidates_token_count or 0
            except Exception:
                pass

            # Log API call
            log_api_call(
                logger,
                model=self.config.gemini.model_name,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                duration_ms=duration_ms,
            )

            # Update session stats
            session.update_token_usage(input_tokens + output_tokens)

            content = response.text

            return APIResponse(
                success=True,
                content=content,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                duration_ms=duration_ms,
            )

        except google_exceptions.InvalidArgument as e:
            log_error(logger, "INVALID_ARGUMENT", str(e))
            return APIResponse(
                success=False,
                content="I couldn't process that request. Could you rephrase your question?",
                error_type="INVALID_ARGUMENT",
                error_message=str(e),
            )

        except google_exceptions.ResourceExhausted as e:
            log_error(logger, "RATE_LIMIT", str(e))
            return APIResponse(
                success=False,
                content=CareerAdvisorPrompts.get_rate_limit_response(),
                error_type="RATE_LIMIT",
                error_message=str(e),
            )

        except google_exceptions.Unauthenticated as e:
            log_error(logger, "AUTH_ERROR", str(e))
            return APIResponse(
                success=False,
                content="Authentication failed. Please check your API key configuration.",
                error_type="AUTH_ERROR",
                error_message=str(e),
            )

        except google_exceptions.ServiceUnavailable as e:
            log_error(logger, "SERVICE_UNAVAILABLE", str(e))
            return APIResponse(
                success=False,
                content="The service is temporarily unavailable. Please try again in a moment.",
                error_type="SERVICE_UNAVAILABLE",
                error_message=str(e),
            )

        except Exception as e:
            duration_ms = (time.time() - start_time) * 1000
            log_error(logger, "UNEXPECTED_ERROR", str(e))
            return APIResponse(
                success=False,
                content=CareerAdvisorPrompts.get_error_response(),
                error_type="UNEXPECTED_ERROR",
                error_message=str(e),
                duration_ms=duration_ms,
            )

    def generate_greeting(self) -> str:
        """
        Generate a personalized greeting for new users.

        Returns:
            Greeting message string.
        """
        if not self.is_ready:
            return (
                "👋 Welcome to CareerAI! I'm your personal career advisor. "
                "How can I help you today? Whether it's resume tips, interview prep, "
                "or navigating a career change — I'm here for it!"
            )

        try:
            response = self._model.generate_content(
                CareerAdvisorPrompts.GREETING_PROMPT
            )
            return response.text
        except Exception as e:
            log_error(logger, "GREETING_ERROR", str(e))
            return (
                "👋 Welcome to **CareerAI**! I'm your dedicated career advisor. "
                "I can help you with:\n"
                "- 📄 Resume & cover letter writing\n"
                "- 🎯 Job search strategy\n"
                "- 💼 Interview preparation\n"
                "- 💰 Salary negotiation\n\n"
                "What's your career goal today?"
            )
