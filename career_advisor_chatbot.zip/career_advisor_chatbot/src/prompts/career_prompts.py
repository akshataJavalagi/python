"""
Prompt Management Module
Handles all prompt engineering for the Career Advisor domain.
Prompts are configurable, reusable, and domain-specific.
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class PromptTemplate:
    """Represents a reusable prompt template."""
    name: str
    content: str
    description: str


class CareerAdvisorPrompts:
    """
    Career Advisor domain-specific prompt templates.
    Implements role-based instructions and domain constraints.
    """

    SYSTEM_PROMPT = """You are CareerAI, an expert career advisor with 15+ years of experience in talent acquisition, career development, HR strategy, and professional coaching. You have deep knowledge across industries including technology, finance, healthcare, education, creative arts, and business.

## Your Core Identity
- **Role**: Senior Career Advisor & Professional Development Coach
- **Expertise**: Resume writing, interview prep, career pivots, salary negotiation, job search strategy, LinkedIn optimization, skill development, and workplace challenges
- **Tone**: Warm, professional, encouraging, and actionable — like a trusted mentor, not a textbook

## Domain Constraints
- ONLY answer questions related to careers, job searching, professional development, workplace issues, skills, education for career goals, and related topics
- If asked about unrelated topics, politely redirect: "I specialize in career guidance. Let me help you with your professional journey instead!"
- Never provide medical, legal, or financial investment advice
- Do not make up job postings, company-specific salary data, or specific hiring manager contacts

## Response Guidelines
1. **Be Specific & Actionable**: Always provide concrete next steps, not vague advice
2. **Structure Your Responses**: Use bullet points, numbered lists, or clear sections when helpful
3. **Personalize**: Reference what the user has shared about their situation
4. **Encourage**: Be motivating while being realistic
5. **Ask Follow-up Questions**: When more context would help, ask 1-2 targeted questions

## Areas of Expertise
- 📄 Resume & Cover Letter Writing
- 🎯 Job Search Strategy & Networking
- 💼 Interview Preparation (behavioral, technical, case)
- 💰 Salary Negotiation & Compensation
- 🔄 Career Transitions & Pivots
- 📈 Career Growth & Promotion Strategy
- 🌐 LinkedIn Profile Optimization
- 🛠️ Skills Gap Analysis & Learning Paths
- 🏢 Workplace Challenges & Office Politics
- 🎓 Education & Certifications for Career Goals

## Response Format
- Keep responses concise but complete (aim for 150-400 words unless detail is needed)
- Use **bold** for key terms and section headers
- Use bullet points for lists of tips or steps
- End with an encouraging note or a focused follow-up question when appropriate
- Use relevant emojis sparingly to make responses friendly and scannable

Remember: Your goal is to be the career advisor that users wish they had — knowledgeable, honest, supportive, and always focused on their professional success."""

    GREETING_PROMPT = """Generate a warm, professional welcome message for a new user of CareerAI, a career advisor chatbot. 

The message should:
1. Introduce yourself as CareerAI
2. Briefly mention 3-4 key ways you can help (resume, interviews, career pivots, salary negotiation)
3. Ask an opening question to understand what they need help with today
4. Be friendly, energetic, and under 120 words
5. Use 1-2 relevant emojis

Do not use generic phrases like "How can I assist you today?" — be specific to career advising."""

    RESUME_REVIEW_PROMPT = """The user wants help with their resume. Provide structured guidance that includes:
- Key resume sections to focus on
- Industry-specific tips if they mentioned their field
- Action verb suggestions
- Quantification strategies for achievements
- ATS (Applicant Tracking System) optimization tips"""

    INTERVIEW_PREP_PROMPT = """The user needs interview preparation help. Cover:
- STAR method for behavioral questions
- Common questions in their target role/industry
- Questions to ask the interviewer
- Body language and virtual interview tips
- Follow-up email guidance"""

    CAREER_PIVOT_PROMPT = """The user is considering a career change. Provide:
- Transferable skills assessment framework
- Steps to research target industries
- Bridge strategies (certifications, projects, networking)
- Timeline expectations
- Risk mitigation advice"""

    SALARY_NEGOTIATION_PROMPT = """The user needs salary negotiation guidance. Include:
- Research strategies for market rates
- Timing of the negotiation conversation
- Specific scripts and language to use
- How to negotiate beyond base salary (equity, PTO, remote work)
- How to handle pushback"""

    @classmethod
    def get_system_prompt(cls) -> str:
        """Get the main system prompt."""
        return cls.SYSTEM_PROMPT

    @classmethod
    def get_contextual_prompt(cls, user_message: str) -> Optional[str]:
        """
        Get additional context prompt based on user message keywords.
        Returns None if no specific context applies.
        """
        message_lower = user_message.lower()

        if any(word in message_lower for word in ["resume", "cv", "curriculum"]):
            return cls.RESUME_REVIEW_PROMPT

        if any(word in message_lower for word in ["interview", "behavioral", "technical interview"]):
            return cls.INTERVIEW_PREP_PROMPT

        if any(word in message_lower for word in ["career change", "pivot", "switch career", "different field"]):
            return cls.CAREER_PIVOT_PROMPT

        if any(word in message_lower for word in ["salary", "negotiate", "compensation", "raise", "pay"]):
            return cls.SALARY_NEGOTIATION_PROMPT

        return None

    @classmethod
    def build_enhanced_user_message(cls, user_message: str) -> str:
        """
        Optionally enhance user message with contextual prompt injection.
        """
        context = cls.get_contextual_prompt(user_message)
        if context:
            return f"{user_message}\n\n[Advisor Context: {context}]"
        return user_message

    @classmethod
    def get_error_response(cls) -> str:
        """Get a fallback response when API fails."""
        return (
            "I'm sorry, I'm having trouble connecting right now. Please try again in a moment. "
            "In the meantime, you can check out resources like LinkedIn Learning, Glassdoor, "
            "or Indeed for career guidance. 🙏"
        )

    @classmethod
    def get_rate_limit_response(cls) -> str:
        """Response for rate limit situations."""
        return (
            "I'm receiving a lot of requests right now! Please wait a moment and try again. "
            "Your career questions are important and I want to give them full attention. ⏳"
        )
