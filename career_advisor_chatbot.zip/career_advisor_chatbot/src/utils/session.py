"""
Session Management Module
Handles chat session state, history management, and memory.
"""

import uuid
from datetime import datetime
from typing import List, Optional
from dataclasses import dataclass, field


@dataclass
class ChatMessage:
    """Represents a single chat message."""
    role: str  # "user" or "assistant"
    content: str
    timestamp: datetime = field(default_factory=datetime.now)
    message_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])

    def to_dict(self) -> dict:
        """Convert to dictionary for API consumption."""
        return {
            "role": self.role,
            "parts": [{"text": self.content}],
        }

    def to_display_dict(self) -> dict:
        """Convert to display-friendly dictionary."""
        return {
            "role": self.role,
            "content": self.content,
            "timestamp": self.timestamp.strftime("%H:%M"),
            "message_id": self.message_id,
        }


class SessionManager:
    """Manages chat session state and conversation history."""

    def __init__(self, max_history_turns: int = 20):
        self.session_id = str(uuid.uuid4())
        self.created_at = datetime.now()
        self.max_history_turns = max_history_turns
        self.messages: List[ChatMessage] = []
        self.total_tokens_used = 0
        self.total_api_calls = 0

    def add_message(self, role: str, content: str) -> ChatMessage:
        """Add a new message to the session history."""
        message = ChatMessage(role=role, content=content)
        self.messages.append(message)
        self._trim_history()
        return message

    def get_history_for_api(self) -> List[dict]:
        """Get conversation history formatted for Gemini API."""
        # Exclude the last message (current user input) - it's sent separately
        history = self.messages[:-1] if self.messages else []
        return [msg.to_dict() for msg in history]

    def get_display_history(self) -> List[dict]:
        """Get conversation history for UI display."""
        return [msg.to_display_dict() for msg in self.messages]

    def clear_history(self):
        """Clear all conversation history."""
        self.messages = []

    def _trim_history(self):
        """Keep history within max_history_turns limit."""
        max_messages = self.max_history_turns * 2  # Each turn = user + assistant
        if len(self.messages) > max_messages:
            self.messages = self.messages[-max_messages:]

    def update_token_usage(self, tokens: int):
        """Update total token usage counter."""
        self.total_tokens_used += tokens
        self.total_api_calls += 1

    def get_session_stats(self) -> dict:
        """Get session statistics."""
        return {
            "session_id": self.session_id[:8],
            "messages": len(self.messages),
            "tokens_used": self.total_tokens_used,
            "api_calls": self.total_api_calls,
            "duration_minutes": round(
                (datetime.now() - self.created_at).total_seconds() / 60, 1
            ),
        }

    @property
    def message_count(self) -> int:
        return len(self.messages)

    @property
    def is_empty(self) -> bool:
        return len(self.messages) == 0
