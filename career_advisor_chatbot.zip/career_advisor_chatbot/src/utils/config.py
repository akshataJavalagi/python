"""
Configuration Management Module
Handles all application configuration loading from environment variables and config files.
"""

import os
from dataclasses import dataclass, field
from typing import Optional
from dotenv import load_dotenv

# Load .env file if present
load_dotenv()


@dataclass
class GeminiConfig:
    """Gemini API configuration."""
    api_key: str = ""
    model_name: str = "gemini-1.5-flash"
    max_output_tokens: int = 2048
    temperature: float = 0.7
    top_p: float = 0.9
    top_k: int = 40


@dataclass
class ChatConfig:
    """Chat session configuration."""
    max_history_turns: int = 20
    session_timeout_minutes: int = 60
    enable_streaming: bool = True


@dataclass
class AppConfig:
    """Main application configuration."""
    app_name: str = "CareerAI"
    app_version: str = "1.0.0"
    debug_mode: bool = False
    log_level: str = "INFO"
    domain: str = "career_advisor"
    gemini: GeminiConfig = field(default_factory=GeminiConfig)
    chat: ChatConfig = field(default_factory=ChatConfig)


def load_config() -> AppConfig:
    """
    Load application configuration from environment variables.

    Returns:
        AppConfig: Populated application configuration object.
    """
    gemini_config = GeminiConfig(
        api_key=os.getenv("GEMINI_API_KEY", ""),
        model_name=os.getenv("GEMINI_MODEL", "gemini-1.5-flash"),
        max_output_tokens=int(os.getenv("GEMINI_MAX_TOKENS", "2048")),
        temperature=float(os.getenv("GEMINI_TEMPERATURE", "0.7")),
        top_p=float(os.getenv("GEMINI_TOP_P", "0.9")),
        top_k=int(os.getenv("GEMINI_TOP_K", "40")),
    )

    chat_config = ChatConfig(
        max_history_turns=int(os.getenv("MAX_HISTORY_TURNS", "20")),
        session_timeout_minutes=int(os.getenv("SESSION_TIMEOUT_MINUTES", "60")),
        enable_streaming=os.getenv("ENABLE_STREAMING", "true").lower() == "true",
    )

    app_config = AppConfig(
        app_name=os.getenv("APP_NAME", "CareerAI"),
        app_version=os.getenv("APP_VERSION", "1.0.0"),
        debug_mode=os.getenv("DEBUG_MODE", "false").lower() == "true",
        log_level=os.getenv("LOG_LEVEL", "INFO"),
        domain=os.getenv("DOMAIN", "career_advisor"),
        gemini=gemini_config,
        chat=chat_config,
    )

    return app_config


def validate_config(config: AppConfig) -> tuple[bool, Optional[str]]:
    """
    Validate configuration settings.

    Args:
        config: Application configuration to validate.

    Returns:
        Tuple of (is_valid, error_message)
    """
    if not config.gemini.api_key:
        return False, "GEMINI_API_KEY environment variable is not set."

    if config.gemini.temperature < 0 or config.gemini.temperature > 1:
        return False, "GEMINI_TEMPERATURE must be between 0 and 1."

    if config.gemini.max_output_tokens < 1 or config.gemini.max_output_tokens > 8192:
        return False, "GEMINI_MAX_TOKENS must be between 1 and 8192."

    return True, None
