"""
Logging Utility Module
Provides structured logging for the application.
"""

import logging
import os
import sys
from datetime import datetime
from pathlib import Path


def get_logger(name: str) -> logging.Logger:
    """
    Get a configured logger instance.

    Args:
        name: Logger name (typically __name__)

    Returns:
        Configured logger instance.
    """
    log_level = os.getenv("LOG_LEVEL", "INFO").upper()
    log_dir = Path("logs")
    log_dir.mkdir(exist_ok=True)

    logger = logging.getLogger(name)

    # Avoid adding duplicate handlers
    if logger.handlers:
        return logger

    logger.setLevel(getattr(logging, log_level, logging.INFO))

    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(getattr(logging, log_level, logging.INFO))

    # File handler
    log_filename = log_dir / f"app_{datetime.now().strftime('%Y%m%d')}.log"
    file_handler = logging.FileHandler(log_filename)
    file_handler.setLevel(logging.DEBUG)

    # Formatter
    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    console_handler.setFormatter(formatter)
    file_handler.setFormatter(formatter)

    logger.addHandler(console_handler)
    logger.addHandler(file_handler)

    return logger


def log_api_call(logger: logging.Logger, model: str, input_tokens: int, output_tokens: int, duration_ms: float):
    """Log API call metadata for monitoring."""
    logger.info(
        f"API_CALL | model={model} | input_tokens={input_tokens} | "
        f"output_tokens={output_tokens} | duration_ms={duration_ms:.2f}"
    )


def log_error(logger: logging.Logger, error_type: str, error_msg: str, context: dict = None):
    """Log structured error information."""
    ctx_str = f" | context={context}" if context else ""
    logger.error(f"ERROR | type={error_type} | message={error_msg}{ctx_str}")
