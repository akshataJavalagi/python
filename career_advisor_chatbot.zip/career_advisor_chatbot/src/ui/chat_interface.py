"""
Chat Interface UI Module
Renders the Streamlit-based chat interface for the Career Advisor chatbot.
Implements chat-style UI, real-time rendering, loading indicators.
"""

import streamlit as st
from src.utils.config import AppConfig, validate_config
from src.utils.session import SessionManager
from src.utils.logger import get_logger
from src.api.gemini_client import GeminiClient

logger = get_logger(__name__)


def apply_custom_styles():
    """Apply custom CSS for a polished chat interface."""
    st.markdown(
        """
        <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&family=Fraunces:ital,wght@0,400;0,700;1,400&display=swap');

        /* ── Global ── */
        html, body, [class*="css"] {
            font-family: 'Plus Jakarta Sans', sans-serif;
        }
        .main { background: #0d0f14; }
        .block-container { padding-top: 1.5rem !important; max-width: 900px; }

        /* ── Header ── */
        .careerai-header {
            background: linear-gradient(135deg, #0d0f14 0%, #13161e 100%);
            border: 1px solid #1e2330;
            border-radius: 16px;
            padding: 1.5rem 2rem;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        .careerai-logo {
            font-family: 'Fraunces', serif;
            font-size: 2rem;
            font-weight: 700;
            background: linear-gradient(135deg, #6ee7f7, #a78bfa);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            line-height: 1;
        }
        .careerai-tagline {
            color: #64748b;
            font-size: 0.85rem;
            letter-spacing: 0.05em;
            text-transform: uppercase;
        }
        .careerai-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: rgba(110, 231, 247, 0.1);
            border: 1px solid rgba(110, 231, 247, 0.2);
            border-radius: 20px;
            padding: 4px 12px;
            color: #6ee7f7;
            font-size: 0.75rem;
            font-weight: 500;
        }
        .badge-dot {
            width: 6px; height: 6px;
            background: #6ee7f7;
            border-radius: 50%;
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.3; }
        }

        /* ── Chat Messages ── */
        .chat-container {
            display: flex;
            flex-direction: column;
            gap: 1rem;
            padding: 0.5rem 0;
        }
        .message-wrapper {
            display: flex;
            flex-direction: column;
            max-width: 82%;
        }
        .message-wrapper.user { align-self: flex-end; align-items: flex-end; }
        .message-wrapper.assistant { align-self: flex-start; align-items: flex-start; }

        .message-bubble {
            padding: 0.85rem 1.1rem;
            border-radius: 16px;
            font-size: 0.92rem;
            line-height: 1.6;
        }
        .message-bubble.user {
            background: linear-gradient(135deg, #4f46e5, #7c3aed);
            color: #f1f5f9;
            border-bottom-right-radius: 4px;
        }
        .message-bubble.assistant {
            background: #13161e;
            border: 1px solid #1e2330;
            color: #cbd5e1;
            border-bottom-left-radius: 4px;
        }
        .message-meta {
            font-size: 0.7rem;
            color: #475569;
            margin-top: 4px;
            padding: 0 4px;
        }
        .sender-label {
            font-weight: 600;
            font-size: 0.75rem;
            color: #64748b;
            margin-bottom: 4px;
            padding: 0 4px;
        }
        .sender-label.assistant { color: #6ee7f7; }
        .sender-label.user { color: #a78bfa; text-align: right; }

        /* ── Suggestions ── */
        .suggestions-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 0.6rem;
            margin: 1rem 0;
        }
        .suggestion-card {
            background: #13161e;
            border: 1px solid #1e2330;
            border-radius: 10px;
            padding: 0.7rem 0.9rem;
            cursor: pointer;
            transition: all 0.2s;
            font-size: 0.82rem;
            color: #94a3b8;
        }
        .suggestion-card:hover {
            border-color: #6ee7f7;
            color: #e2e8f0;
            background: #161b24;
        }
        .suggestion-icon { font-size: 1rem; margin-right: 6px; }

        /* ── Input Area ── */
        .stChatInputContainer > div {
            background: #13161e !important;
            border: 1px solid #1e2330 !important;
            border-radius: 12px !important;
        }
        .stChatInputContainer textarea {
            color: #e2e8f0 !important;
            font-family: 'Plus Jakarta Sans', sans-serif !important;
        }

        /* ── Sidebar ── */
        .sidebar-section {
            background: #13161e;
            border: 1px solid #1e2330;
            border-radius: 10px;
            padding: 1rem;
            margin-bottom: 0.8rem;
        }
        .sidebar-title {
            font-size: 0.75rem;
            font-weight: 600;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            margin-bottom: 0.6rem;
        }
        .stat-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 4px 0;
            font-size: 0.82rem;
            color: #94a3b8;
        }
        .stat-value {
            color: #6ee7f7;
            font-weight: 600;
        }

        /* ── Misc ── */
        .stSpinner > div { border-color: #6ee7f7 !important; }
        h1,h2,h3 { font-family: 'Fraunces', serif !important; }
        .stAlert { border-radius: 10px !important; }

        /* Hide streamlit branding */
        #MainMenu {visibility: hidden;}
        footer {visibility: hidden;}
        </style>
        """,
        unsafe_allow_html=True,
    )


def render_header():
    """Render the application header."""
    st.markdown(
        """
        <div class="careerai-header">
            <div>
                <div class="careerai-logo">CareerAI</div>
                <div class="careerai-tagline">Powered by Google Gemini</div>
            </div>
            <div style="margin-left:auto">
                <div class="careerai-badge">
                    <div class="badge-dot"></div>
                    Live
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_sidebar(session: SessionManager, config: AppConfig):
    """Render the sidebar with stats and controls."""
    with st.sidebar:
        st.markdown("### 🚀 CareerAI")
        st.markdown("*Your Personal Career Advisor*")
        st.divider()

        # Session Stats
        stats = session.get_session_stats()
        st.markdown(
            f"""
            <div class="sidebar-section">
                <div class="sidebar-title">Session Stats</div>
                <div class="stat-row">Messages <span class="stat-value">{stats['messages']}</span></div>
                <div class="stat-row">Tokens Used <span class="stat-value">{stats['tokens_used']:,}</span></div>
                <div class="stat-row">Duration <span class="stat-value">{stats['duration_minutes']}m</span></div>
                <div class="stat-row">Session ID <span class="stat-value">{stats['session_id']}</span></div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        # Quick Topics
        st.markdown("**Quick Topics**")
        topics = {
            "📄 Resume Help": "Help me improve my resume",
            "🎯 Job Search": "What's the best job search strategy?",
            "💼 Interview Prep": "Help me prepare for a job interview",
            "💰 Salary Negotiation": "How do I negotiate a better salary?",
            "🔄 Career Change": "I want to change my career. Where do I start?",
            "📈 Get Promoted": "How can I position myself for a promotion?",
        }

        for label, prompt in topics.items():
            if st.button(label, key=f"topic_{label}", use_container_width=True):
                st.session_state.quick_prompt = prompt
                st.rerun()

        st.divider()

        # Controls
        if st.button("🗑️ Clear Conversation", use_container_width=True, type="secondary"):
            session.clear_history()
            st.session_state.messages = []
            st.session_state.greeted = False
            st.rerun()

        st.divider()

        # Model info
        st.caption(f"Model: `{config.gemini.model_name}`")
        st.caption(f"v{config.app_version}")


def render_message(role: str, content: str, timestamp: str = ""):
    """Render a single chat message with styling."""
    icon = "🤖" if role == "assistant" else "👤"
    label = "CareerAI" if role == "assistant" else "You"

    st.markdown(
        f"""
        <div class="message-wrapper {role}">
            <div class="sender-label {role}">{icon} {label}</div>
            <div class="message-bubble {role}">{content}</div>
            {f'<div class="message-meta">{timestamp}</div>' if timestamp else ''}
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_suggestion_chips():
    """Render quick-start suggestion chips for new users."""
    suggestions = [
        ("📄", "Review my resume", "Can you help me improve my resume? I'm applying for software engineer roles."),
        ("🎯", "Job search tips", "What are the most effective job search strategies in 2024?"),
        ("💼", "Interview prep", "Help me prepare for a behavioral interview at a tech company."),
        ("💰", "Negotiate salary", "I got a job offer. How do I negotiate a better compensation package?"),
    ]

    cols = st.columns(2)
    for i, (icon, label, prompt) in enumerate(suggestions):
        with cols[i % 2]:
            if st.button(f"{icon} {label}", key=f"chip_{i}", use_container_width=True):
                st.session_state.quick_prompt = prompt
                st.rerun()


def initialize_session_state(config: AppConfig):
    """Initialize Streamlit session state variables."""
    if "session_manager" not in st.session_state:
        st.session_state.session_manager = SessionManager(
            max_history_turns=config.chat.max_history_turns
        )

    if "gemini_client" not in st.session_state:
        st.session_state.gemini_client = GeminiClient(config)

    if "messages" not in st.session_state:
        st.session_state.messages = []

    if "greeted" not in st.session_state:
        st.session_state.greeted = False

    if "quick_prompt" not in st.session_state:
        st.session_state.quick_prompt = None


def render_chat_interface(config: AppConfig):
    """
    Main function to render the complete chat interface.

    Args:
        config: Application configuration.
    """
    apply_custom_styles()
    render_header()

    # Initialize session state
    initialize_session_state(config)

    session: SessionManager = st.session_state.session_manager
    client: GeminiClient = st.session_state.gemini_client

    # Render sidebar
    render_sidebar(session, config)

    # Check API key configuration
    is_valid, error_msg = validate_config(config)
    if not is_valid:
        st.error(
            f"⚠️ **Configuration Error**: {error_msg}\n\n"
            "Please set the `GEMINI_API_KEY` environment variable and restart the app.",
            icon="🔑",
        )
        st.info(
            "**Setup Instructions:**\n"
            "1. Get your free API key from [Google AI Studio](https://aistudio.google.com/)\n"
            "2. Create a `.env` file: `GEMINI_API_KEY=your_key_here`\n"
            "3. Restart the application",
            icon="ℹ️",
        )
        return

    # Generate greeting for new sessions
    if not st.session_state.greeted:
        with st.spinner("CareerAI is warming up..."):
            greeting = client.generate_greeting()
        st.session_state.messages.append({
            "role": "assistant",
            "content": greeting,
            "timestamp": "",
        })
        session.add_message("model", greeting)
        st.session_state.greeted = True

    # Display conversation history
    for msg in st.session_state.messages:
        render_message(msg["role"], msg["content"], msg.get("timestamp", ""))

    # Show suggestion chips if conversation just started
    if len(st.session_state.messages) <= 1:
        st.markdown("---")
        st.markdown("**✨ Quick starts:**")
        render_suggestion_chips()

    # Handle quick prompts from sidebar/chips
    if st.session_state.quick_prompt:
        user_input = st.session_state.quick_prompt
        st.session_state.quick_prompt = None
    else:
        user_input = None

    # Chat input
    chat_input = st.chat_input("Ask me anything about your career journey...")

    if chat_input:
        user_input = chat_input

    # Process user input
    if user_input:
        # Add user message to display
        from datetime import datetime
        timestamp = datetime.now().strftime("%H:%M")

        st.session_state.messages.append({
            "role": "user",
            "content": user_input,
            "timestamp": timestamp,
        })
        render_message("user", user_input, timestamp)

        # Add to session memory
        session.add_message("user", user_input)

        # Generate AI response with loading indicator
        with st.spinner("CareerAI is thinking..."):
            api_response = client.generate_response(user_input, session)

        response_content = api_response.content

        # Add assistant response to display
        st.session_state.messages.append({
            "role": "assistant",
            "content": response_content,
            "timestamp": datetime.now().strftime("%H:%M"),
        })
        render_message("assistant", response_content)

        # Add to session memory
        session.add_message("model", response_content)

        # Log any errors in debug mode
        if not api_response.success and config.debug_mode:
            st.warning(f"Debug: {api_response.error_type} - {api_response.error_message}")

        # Show token usage in debug mode
        if config.debug_mode and api_response.success:
            st.caption(
                f"Tokens: {api_response.input_tokens} in / {api_response.output_tokens} out | "
                f"{api_response.duration_ms:.0f}ms"
            )

        st.rerun()
