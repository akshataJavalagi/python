from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from models import Session, URL
import string
import random
import validators

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Change this in production

def generate_short_code(length=6):
    chars = string.ascii_letters + string.digits
    return ''.join(random.choice(chars) for _ in range(length))

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/shorten', methods=['POST'])
def shorten():
    original_url = request.form.get('url')
    if not original_url:
        flash('Please enter a URL.', 'error')
        return redirect(url_for('index'))

    if not validators.url(original_url):
        flash('Please enter a valid URL.', 'error')
        return redirect(url_for('index'))

    session = Session()
    try:
        # Check if URL already exists
        existing_url = session.query(URL).filter_by(original_url=original_url).first()
        if existing_url:
            short_code = existing_url.short_code
        else:
            # Generate unique short code
            short_code = generate_short_code()
            while session.query(URL).filter_by(short_code=short_code).first():
                short_code = generate_short_code()

            new_url = URL(original_url=original_url, short_code=short_code)
            session.add(new_url)
            session.commit()

        shortened_url = url_for('redirect_to_url', short_code=short_code, _external=True)
        flash(f'Shortened URL: {shortened_url}', 'success')
    except Exception as e:
        session.rollback()
        flash('An error occurred. Please try again.', 'error')
    finally:
        session.close()

    return redirect(url_for('index'))

@app.route('/<short_code>')
def redirect_to_url(short_code):
    session = Session()
    try:
        url_entry = session.query(URL).filter_by(short_code=short_code).first()
        if url_entry:
            return redirect(url_entry.original_url)
        else:
            return 'URL not found', 404
    finally:
        session.close()

@app.route('/history')
def history():
    session = Session()
    try:
        urls = session.query(URL).order_by(URL.created_at.desc()).all()
        return render_template('history.html', urls=urls)
    finally:
        session.close()

if __name__ == '__main__':
    app.run(debug=True)
