# URL Shortener Web App - TODO List

- [x] Create requirements.txt with dependencies (Flask, SQLAlchemy, validators)
- [x] Create app.py (Flask app setup, routes, URL shortening logic)
- [x] Create models.py (SQLAlchemy URL model)
- [x] Create templates/index.html (Home page with form)
- [x] Create templates/history.html (History page with table)
- [x] Create static/css/style.css (Bootstrap + custom styles)
- [x] Create static/js/script.js (Copy button functionality)
- [x] Install dependencies
- [ ] Run and test the app
