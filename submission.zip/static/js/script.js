document.addEventListener('DOMContentLoaded', function() {
    // Copy button functionality
    document.querySelectorAll('.copy-btn').forEach(button => {
        button.addEventListener('click', function() {
            const url = this.getAttribute('data-url');
            const input = this.previousElementSibling.previousElementSibling.querySelector('.short-url') || this.previousElementSibling;
            input.select();
            document.execCommand('copy');
            // Show feedback
            const originalText = this.textContent;
            this.textContent = 'Copied!';
            this.classList.remove('btn-primary');
            this.classList.add('btn-success');
            setTimeout(() => {
                this.textContent = originalText;
                this.classList.remove('btn-success');
                this.classList.add('btn-primary');
            }, 2000);
        });
    });

    // For the shortened URL display on home page
    const shortenedUrlInput = document.getElementById('shortened-url');
    if (shortenedUrlInput) {
        const copyBtn = document.getElementById('copy-btn');
        if (copyBtn) {
            copyBtn.addEventListener('click', function() {
                shortenedUrlInput.select();
                document.execCommand('copy');
                const originalText = this.textContent;
                this.textContent = 'Copied!';
                this.classList.remove('btn-primary');
                this.classList.add('btn-success');
                setTimeout(() => {
                    this.textContent = originalText;
                    this.classList.remove('btn-success');
                    this.classList.add('btn-primary');
                }, 2000);
            });
        }
    }
});
