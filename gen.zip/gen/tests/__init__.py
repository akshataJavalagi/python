"""
Tests package for Career Advisor Chatbot.
"""
