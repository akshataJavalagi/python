"""
Tests for the Gemini API client.
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
from datetime import datetime

from src.api.gemini_client import GeminiClient, GeminiResponse


class TestGeminiClient:
    """Test cases for GeminiClient."""
    
    @patch('src.api.gemini_client.genai.configure')
    @patch('src.api.gemini_client.genai.GenerativeModel')
    def test_client_initialization(self, mock_model, mock_configure):
        """Test client initialization with API key."""
        # Arrange
        api_key = "test-api-key"
        
        # Act
        client = GeminiClient(api_key=api_key)
        
        # Assert
        assert client.api_key == api_key
        mock_configure.assert_called_once_with(api_key=api_key)
    
    @patch('src.api.gemini_client.genai.configure')
    @patch('src.api.gemini_client.genai.GenerativeModel')
    def test_client_initialization_no_api_key(self, mock_model, mock_configure):
        """Test client initialization without API key raises error."""
        # Arrange & Act & Assert
        with pytest.raises(ValueError, match="GEMINI_API_KEY is not set"):
            GeminiClient(api_key="")
    
    @patch('src.api.gemini_client.genai.configure')
    @patch('src.api.gemini_client.genai.GenerativeModel')
    def test_generate_content(self, mock_model, mock_configure):
        """Test content generation."""
        # Arrange
        api_key = "test-api-key"
        client = GeminiClient(api_key=api_key)
        
        # Create mock response
        mock_response = MagicMock()
        mock_response.text = "Test response"
        mock_response.usage_metadata.prompt_token_count = 10
        mock_response.usage_metadata.candidates_token_count = 20
        
        client._model.generate_content = Mock(return_value=mock_response)
        
        # Act
        result = client.generate_content("Test prompt")
        
        # Assert
        assert isinstance(result, GeminiResponse)
        assert result.text == "Test response"
        assert result.prompt_token_count == 10
        assert result.candidate_token_count == 20
    
    @patch('src.api.gemini_client.genai.configure')
    @patch('src.api.gemini_client.genai.GenerativeModel')
    def test_generate_content_with_system_prompt(self, mock_model, mock_configure):
        """Test content generation with system prompt."""
        # Arrange
        api_key = "test-api-key"
        client = GeminiClient(api_key=api_key)
        
        # Create mock response
        mock_response = MagicMock()
        mock_response.text = "Test response"
        mock_response.usage_metadata.prompt_token_count = 10
        mock_response.usage_metadata.candidates_token_count = 20
        
        client._model.generate_content = Mock(return_value=mock_response)
        
        # Act
        result = client.generate_content("User prompt", "System prompt")
        
        # Assert
        assert "System prompt" in client._model.generate_content.call_args[0][0]
        assert "User prompt" in client._model.generate_content.call_args[0][0]
    
    @patch('src.api.gemini_client.genai.configure')
    @patch('src.api.gemini_client.genai.GenerativeModel')
    @patch('src.api.gemini_client.genai.list_models')
    def test_validate_api_key(self, mock_list, mock_model, mock_configure):
        """Test API key validation."""
        # Arrange
        api_key = "test-api-key"
        client = GeminiClient(api_key=api_key)
        
        # Act
        result = client.validate_api_key()
        
        # Assert
        assert result is True
        mock_list.assert_called_once()
    
    @patch('src.api.gemini_client.get_settings')
    @patch('src.api.gemini_client.genai.configure')
    @patch('src.api.gemini_client.genai.GenerativeModel')
    def test_update_temperature(self, mock_model, mock_configure, mock_settings):
        """Test temperature update."""
        # Arrange
        mock_settings.return_value.api.gemini.model_name = "gemini-pro"
        mock_settings.return_value.api.gemini.temperature = 0.7
        mock_settings.return_value.api.gemini.max_tokens = 2048
        mock_settings.return_value.api.gemini.top_p = 0.95
        mock_settings.return_value.api.gemini.top_k = 40
        
        api_key = "test-api-key"
        client = GeminiClient(api_key=api_key)
        
        # Act
        client.update_temperature(0.9)
        
        # Assert
        assert client.temperature == 0.9
    
    @patch('src.api.gemini_client.get_settings')
    @patch('src.api.gemini_client.genai.configure')
    @patch('src.api.gemini_client.genai.GenerativeModel')
    def test_update_max_tokens(self, mock_model, mock_configure, mock_settings):
        """Test max tokens update."""
        # Arrange
        mock_settings.return_value.api.gemini.model_name = "gemini-pro"
        mock_settings.return_value.api.gemini.temperature = 0.7
        mock_settings.return_value.api.gemini.max_tokens = 2048
        mock_settings.return_value.api.gemini.top_p = 0.95
        mock_settings.return_value.api.gemini.top_k = 40
        
        api_key = "test-api-key"
        client = GeminiClient(api_key=api_key)
        
        # Act
        client.update_max_tokens(4096)
        
        # Assert
        assert client.max_tokens == 4096


class TestGeminiResponse:
    """Test cases for GeminiResponse dataclass."""
    
    def test_response_creation(self):
        """Test creating a GeminiResponse."""
        # Act
        response = GeminiResponse(
            text="Test response",
            model="gemini-pro",
            prompt_token_count=10,
            candidate_token_count=20,
            timestamp=datetime.now()
        )
        
        # Assert
        assert response.text == "Test response"
        assert response.model == "gemini-pro"
        assert response.prompt_token_count == 10
        assert response.candidate_token_count == 20
