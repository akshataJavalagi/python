"""
Tests for the Prompt Manager.
"""

import pytest
from unittest.mock import Mock, patch

from src.prompts.prompt_manager import PromptManager, PromptTemplate, ConversationMessage


class TestPromptManager:
    """Test cases for PromptManager."""
    
    @patch('src.prompts.prompt_manager.get_settings')
    def test_initialization(self, mock_settings):
        """Test prompt manager initialization."""
        # Arrange
        mock_settings.return_value.prompts = None
        mock_settings.return_value.session.max_conversation_turns = 10
        
        # Act
        manager = PromptManager()
        
        # Assert
        assert manager is not None
        assert len(manager._templates) > 0
    
    @patch('src.prompts.prompt_manager.get_settings')
    def test_get_system_prompt(self, mock_settings):
        """Test getting system prompt."""
        # Arrange
        mock_settings.return_value.prompts = None
        mock_settings.return_value.session.max_conversation_turns = 10
        
        manager = PromptManager()
        
        # Act
        system_prompt = manager.get_system_prompt()
        
        # Assert
        assert system_prompt is not None
        assert len(system_prompt) > 0
        assert "Career Advisor" in system_prompt
    
    @patch('src.prompts.prompt_manager.get_settings')
    def test_get_user_prompt_without_history(self, mock_settings):
        """Test building user prompt without history."""
        # Arrange
        mock_settings.return_value.prompts = None
        mock_settings.return_value.session.max_conversation_turns = 10
        
        manager = PromptManager()
        
        # Act
        user_prompt = manager.get_user_prompt("What are good career options?")
        
        # Assert
        assert "What are good career options?" in user_prompt
    
    @patch('src.prompts.prompt_manager.get_settings')
    def test_get_user_prompt_with_history(self, mock_settings):
        """Test building user prompt with conversation history."""
        # Arrange
        mock_settings.return_value.prompts = None
        mock_settings.return_value.session.max_conversation_turns = 10
        
        manager = PromptManager()
        
        history = [
            ConversationMessage(role="user", content="I need career advice"),
            ConversationMessage(role="assistant", content="I'd be happy to help!")
        ]
        
        # Act
        user_prompt = manager.get_user_prompt(
            "What about data science?",
            conversation_history=history
        )
        
        # Assert
        assert "I need career advice" in user_prompt
        assert "I'd be happy to help!" in user_prompt
        assert "What about data science?" in user_prompt
    
    @patch('src.prompts.prompt_manager.get_settings')
    def test_get_template(self, mock_settings):
        """Test getting a specific template."""
        # Arrange
        mock_settings.return_value.prompts = None
        mock_settings.return_value.session.max_conversation_turns = 10
        
        manager = PromptManager()
        
        # Act
        template = manager.get_template("resume_review")
        
        # Assert
        assert template is not None
        assert template.name == "resume_review"
    
    @patch('src.prompts.prompt_manager.get_settings')
    def test_format_template(self, mock_settings):
        """Test formatting a template."""
        # Arrange
        mock_settings.return_value.prompts = None
        mock_settings.return_value.session.max_conversation_turns = 10
        
        manager = PromptManager()
        
        # Act
        formatted = manager.format_template(
            "interview_prep",
            job_title="Software Engineer",
            background="5 years in web development"
        )
        
        # Assert
        assert "Software Engineer" in formatted
        assert "5 years in web development" in formatted
    
    @patch('src.prompts.prompt_manager.get_settings')
    def test_list_templates(self, mock_settings):
        """Test listing all templates."""
        # Arrange
        mock_settings.return_value.prompts = None
        mock_settings.return_value.session.max_conversation_turns = 10
        
        manager = PromptManager()
        
        # Act
        templates = manager.list_templates()
        
        # Assert
        assert len(templates) > 0
        assert "resume_review" in templates
        assert "interview_prep" in templates
    
    @patch('src.prompts.prompt_manager.get_settings')
    def test_build_full_prompt(self, mock_settings):
        """Test building a complete prompt."""
        # Arrange
        mock_settings.return_value.prompts = None
        mock_settings.return_value.session.max_conversation_turns = 10
        
        manager = PromptManager()
        
        history = [
            ConversationMessage(role="user", content="Hello"),
            ConversationMessage(role="assistant", content="Hi! How can I help?")
        ]
        
        # Act
        system_prompt, user_prompt = manager.build_full_prompt(
            user_message="I want to change careers",
            conversation_history=history
        )
        
        # Assert
        assert system_prompt is not None
        assert user_prompt is not None
        assert "career" in user_prompt.lower()


class TestPromptTemplate:
    """Test cases for PromptTemplate."""
    
    def test_template_format(self):
        """Test formatting a template with variables."""
        # Arrange
        template = PromptTemplate(
            name="test",
            template="Hello {name}, you are {age} years old.",
            variables=["name", "age"]
        )
        
        # Act
        formatted = template.format(name="John", age=30)
        
        # Assert
        assert formatted == "Hello John, you are 30 years old."
    
    def test_template_format_missing_variable(self):
        """Test formatting with missing variable."""
        # Arrange
        template = PromptTemplate(
            name="test",
            template="Hello {name}, you are {age} years old.",
            variables=["name", "age"]
        )
        
        # Act
        formatted = template.format(name="John")
        
        # Assert
        assert formatted == "Hello John, you are {age} years old."
