# Career Advisor Chatbot

A production-ready domain-specific chatbot powered by Google Gemini GenAI API, designed to provide career guidance and advice.

## 📋 Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Architecture](#architecture)
- [Project Structure](#project-structure)
- [Setup](#setup)
- [Running Locally](#running-locally)
- [Deployment](#deployment)
- [Configuration](#configuration)
- [Usage](#usage)
- [API Reference](#api-reference)

## 🎯 Overview

This project implements a production-ready GenAI chatbot for career advisory services. It leverages Google Gemini Pro for intelligent responses and features a modern Streamlit-based user interface.

### Domain: Career Advisor

The chatbot provides assistance with:
- Career guidance and planning
- Resume reviews and improvements
- Interview preparation
- Skill development recommendations
- Job search strategies
- Career transition advice

## ✨ Features

### Core Features
- **Gemini API Integration**: Seamless integration with Google Gemini Pro model
- **Multi-turn Conversation Memory**: Context-aware conversations with session management
- **Advanced Prompt Engineering**: Domain-specific prompts with role-based instructions
- **Query Classification**: Automatic detection of query types (resume review, interview prep, etc.)

### Production Features
- **Secure API Key Management**: Environment variable-based configuration
- **Error Handling**: Robust exception handling with fallback mechanisms
- **Logging**: Comprehensive API call and error logging
- **Token Optimization**: Configurable token limits and usage tracking
- **Session Management**: Automatic session cleanup and timeout handling

### User Interface
- **Streamlit UI**: Modern, responsive chat interface
- **Real-time Response**: Streaming responses with loading indicators
- **Conversation History**: Persistent chat history display
- **Quick Templates**: Pre-built prompts for common queries
- **Sidebar Configuration**: Easy API key and settings management

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        User Interface                        │
│                      (Streamlit App)                         │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                      Backend Layer                           │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐    │
│  │   Domain     │  │   Prompts    │  │   Memory     │    │
│  │   Logic      │  │   Manager    │  │   Manager    │    │
│  └──────────────┘  └──────────────┘  └──────────────┘    │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                      Gemini API Layer                        │
│                   (Google Gemini Pro)                        │
└─────────────────────────────────────────────────────────────┘
```

### System Flow
1. User sends message through Streamlit UI
2. Backend receives and classifies the query
3. Prompt manager builds appropriate prompt with context
4. Conversation memory retrieves relevant history
5. Gemini API generates response
6. Response is formatted and displayed to user

## 📁 Project Structure

```
career-advisor-chatbot/
├── config.yaml                 # Application configuration
├── requirements.txt            # Python dependencies
├── .env.example               # Environment variables template
├── README.md                  # Project documentation
├── TODO.md                    # Project tasks
│
├── src/                       # Source code
│   ├── __init__.py
│   ├── config/                # Configuration module
│   │   ├── __init__.py
│   │   └── settings.py       # Settings management
│   │
│   ├── api/                   # API integration
│   │   ├── __init__.py
│   │   └── gemini_client.py  # Gemini API client
│   │
│   ├── prompts/               # Prompt management
│   │   ├── __init__.py
│   │   └── prompt_manager.py  # Prompt templates
│   │
│   ├── memory/                # Conversation memory
│   │   ├── __init__.py
│   │   └── conversation_memory.py  # Session management
│   │
│   └── domain/                # Domain logic
│       ├── __init__.py
│       └── career_advisor.py  # Career advisor implementation
│
└── ui/                        # User interface
    ├── __init__.py
    └── streamlit_app.py       # Streamlit application
```

## 🚀 Setup

### Prerequisites

- Python 3.8 or higher
- Google Gemini API Key

### Installation

1. **Clone the repository**
   
```
bash
   git clone <repository-url>
   cd career-advisor-chatbot
   
```

2. **Create virtual environment**
   
```
bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   
```

3. **Install dependencies**
   
```
bash
   pip install -r requirements.txt
   
```

4. **Configure environment variables**
   
```
bash
   copy .env.example .env
   # Edit .env and add your GEMINI_API_KEY
   
```

5. **Get Gemini API Key**
   - Go to [Google AI Studio](https://makersuite.google.com/app/apikey)
   - Create a new API key
   - Add it to your `.env` file

## 💻 Running Locally

### Option 1: Using Streamlit

```
bash
streamlit run ui/streamlit_app.py
```

The application will open at `http://localhost:8501`

### Option 2: Direct Python Execution

```
bash
python -m ui.streamlit_app
```

## ☁️ Deployment

### AWS EC2 Deployment

1. **Launch EC2 Instance**
   - Choose Ubuntu 20.04 LTS or later
   - Select instance type (t2.micro for testing)
   - Configure security group:
     - Port 22 (SSH)
     - Port 8501 (Streamlit)

2. **Connect to Instance**
   
```
bash
   ssh -i your-key.pem ubuntu@your-public-ip
   
```

3. **Install Dependencies**
   
```
bash
   sudo apt update
   sudo apt install python3-pip python3-venv
   
```

4. **Upload Application**
   
```
bash
   scp -i your-key.pem -r ./career-advisor-chatbot ubuntu@your-public-ip:~/
   
```

5. **Configure and Run**
   
```bash
   cd career-advisor-chatbot
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   
   # Set environment variable
   export GEMINI_API_KEY="your-api-key"
   
   # Run in background
   nohup streamlit run ui/streamlit_app.py --server.port 8501 --server.address 0.0.0.0 > app.log 2>&1 &
   
```

6. **Access the Application**
   - Open `http://your-public-ip:8501` in browser

### Production Considerations

- Use a process manager like `systemd` or `supervisor`
- Set up SSL/TLS with Nginx
- Configure logging to file
- Use environment variables for secrets

## ⚙️ Configuration

### config.yaml

```
yaml
application:
  name: "Career Advisor Chatbot"
  version: "1.0.0"
  environment: "development"

api:
  gemini:
    model_name: "gemini-pro"
    temperature: 0.7
    max_tokens: 2048
    top_p: 0.95
    top_k: 40

session:
  max_conversation_turns: 10
  timeout_minutes: 30

ui:
  page_title: "Career Advisor Chatbot"
  page_icon: "💼"
  layout: "wide"
  initial_message: "Hello! I'm your Career Advisor Assistant..."
```

### Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `GEMINI_API_KEY` | Google Gemini API key | Yes |
| `APP_NAME` | Application name | No |
| `ENVIRONMENT` | Environment (development/production) | No |
| `MODEL_NAME` | Gemini model to use | No |
| `TEMPERATURE` | Response creativity (0.0-1.0) | No |
| `MAX_TOKENS` | Maximum response tokens | No |

## 📖 Usage

### Starting a Conversation

1. Enter your Gemini API key in the sidebar
2. Type your career question in the chat input
3. Receive AI-powered career guidance

### Quick Templates

Use the quick templates for common queries:
- **Resume Review**: Get feedback on your resume
- **Interview Prep**: Prepare for job interviews
- **Skill Development**: Create a learning path
- **Job Search**: Develop a job search strategy

### Query Types

The chatbot automatically detects and handles:
- General career advice
- Resume reviews
- Interview preparation
- Skill development
- Job search strategies
- Career transitions

## 📚 API Reference

### CareerAdvisor.chat()

Process a chat message and get AI response.

```
python
result = career_advisor.chat(
    user_message="What are good career options for someone with marketing background?",
    session_id="optional-session-id"
)
```

**Returns:**
```
python
{
    "success": True,
    "response": "Based on your marketing background...",
    "session_id": "uuid",
    "query_type": "general_advice",
    "metadata": {
        "prompt_tokens": 150,
        "candidate_tokens": 200
    }
}
```

### GeminiClient.validate_api_key()

Validate the Gemini API connection.

```
python
is_valid = gemini_client.validate_api_key()
# Returns: True/False
```

## 🔧 Development

### Running Tests

```
bash
pytest tests/
```

### Code Structure

The project follows clean architecture principles:
- **UI Layer**: Streamlit interface (`ui/`)
- **Backend Layer**: Business logic (`src/domain/`)
- **Integration Layer**: API clients (`src/api/`)
- **Configuration**: Settings and prompts (`src/config/`, `src/prompts/`)

## 📝 License

MIT License

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Open a Pull Request

## 🙏 Acknowledgments

- Google Gemini AI
- Streamlit
- The open-source community
