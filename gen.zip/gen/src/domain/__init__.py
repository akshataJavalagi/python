"""
Domain module for Career Advisor Chatbot.
Contains business logic and domain-specific implementations.
"""

from src.domain.career_advisor import CareerAdvisor, get_career_advisor

__all__ = ['CareerAdvisor', 'get_career_advisor']
