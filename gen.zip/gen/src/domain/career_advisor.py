"""
Career Advisor Domain Logic.
Implements the core chatbot functionality for career guidance.
"""

from typing import Optional, Dict, Any, List
from enum import Enum

from loguru import logger

from src.api.gemini_client import GeminiClient, GeminiResponse
from src.prompts.prompt_manager import PromptManager, get_prompt_manager
from src.memory.conversation_memory import ConversationMemory, SessionManager, get_session_manager
from src.config.settings import get_settings


class QueryType(Enum):
    """Types of queries the career advisor can handle."""
    GENERAL_ADVICE = "general_advice"
    RESUME_REVIEW = "resume_review"
    INTERVIEW_PREP = "interview_prep"
    SKILL_DEVELOPMENT = "skill_development"
    JOB_SEARCH = "job_search"
    CAREER_TRANSITION = "career_transition"
    UNKNOWN = "unknown"


class CareerAdvisor:
    """
    Career Advisor Chatbot implementation.
    Handles career guidance conversations with Gemini AI.
    """
    
    def __init__(
        self,
        gemini_client: Optional[GeminiClient] = None,
        prompt_manager: Optional[PromptManager] = None,
        session_manager: Optional[SessionManager] = None
    ):
        """
        Initialize the Career Advisor.
        
        Args:
            gemini_client: Gemini API client
            prompt_manager: Prompt manager instance
            session_manager: Session manager instance
        """
        self.gemini_client = gemini_client or GeminiClient()
        self.prompt_manager = prompt_manager or get_prompt_manager()
        self.session_manager = session_manager or get_session_manager()
        self.settings = get_settings()
        
        logger.info("CareerAdvisor initialized")
    
    def _classify_query(self, user_message: str) -> QueryType:
        """
        Classify the user query to determine the appropriate template.
        
        Args:
            user_message: The user's message
            
        Returns:
            QueryType classification
        """
        message_lower = user_message.lower()
        
        # Resume related keywords
        resume_keywords = ["resume", "cv", "curriculum vitae", "resume review"]
        if any(keyword in message_lower for keyword in resume_keywords):
            return QueryType.RESUME_REVIEW
        
        # Interview related keywords
        interview_keywords = ["interview", "interview preparation", "interview tips"]
        if any(keyword in message_lower for keyword in interview_keywords):
            return QueryType.INTERVIEW_PREP
        
        # Skill development keywords
        skill_keywords = ["skill", "learn", "develop skill", "improve skill", "training"]
        if any(keyword in message_lower for keyword in skill_keywords):
            return QueryType.SKILL_DEVELOPMENT
        
        # Job search keywords
        job_search_keywords = ["job search", "find job", "job hunting", "job boards"]
        if any(keyword in message_lower for keyword in job_search_keywords):
            return QueryType.JOB_SEARCH
        
        # Career transition keywords
        transition_keywords = ["career change", "career transition", "switch career", "pivot"]
        if any(keyword in message_lower for keyword in transition_keywords):
            return QueryType.CAREER_TRANSITION
        
        return QueryType.GENERAL_ADVICE
    
    def _get_template_for_query(self, query_type: QueryType) -> Optional[str]:
        """
        Get the appropriate template name for a query type.
        
        Args:
            query_type: The classified query type
            
        Returns:
            Template name or None for general advice
        """
        template_map = {
            QueryType.RESUME_REVIEW: "resume_review",
            QueryType.INTERVIEW_PREP: "interview_prep",
            QueryType.SKILL_DEVELOPMENT: "skill_development",
            QueryType.JOB_SEARCH: "job_search",
        }
        
        return template_map.get(query_type)
    
    def chat(
        self,
        user_message: str,
        session_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Process a chat message and return the assistant's response.
        
        Args:
            user_message: The user's message
            session_id: Optional session ID for conversation continuity
            
        Returns:
            Dictionary containing response and metadata
        """
        try:
            # Get or create session
            if session_id:
                session = self.session_manager.get_session(session_id)
                if session is None:
                    session = self.session_manager.create_new_session(session_id)
            else:
                session = self.session_manager.create_session()
                session_id = list(self.session_manager.sessions.keys())[-1]
            
            # Add user message to memory
            session.add_user_message(user_message)
            
            # Classify the query
            query_type = self._classify_query(user_message)
            logger.info(f"Query classified as: {query_type.value}")
            
            # Get appropriate template
            template_name = self._get_template_for_query(query_type)
            
            # Build the full prompt
            system_prompt, user_prompt = self.prompt_manager.build_full_prompt(
                user_message=user_message,
                conversation_history=session.get_conversation_history(),
                template_name=template_name
            )
            
            # Call Gemini API
            logger.info("Calling Gemini API...")
            response = self.gemini_client.generate_content(
                prompt=user_prompt,
                system_prompt=system_prompt
            )
            
            # Add assistant response to memory
            metadata = {
                "query_type": query_type.value,
                "template_used": template_name,
                "prompt_tokens": response.prompt_token_count,
                "candidate_tokens": response.candidate_token_count
            }
            session.add_assistant_message(response.text, metadata)
            
            logger.info("Response generated successfully")
            
            return {
                "success": True,
                "response": response.text,
                "session_id": session_id,
                "query_type": query_type.value,
                "metadata": metadata
            }
            
        except Exception as e:
            logger.error(f"Error in chat: {e}")
            return {
                "success": False,
                "error": str(e),
                "session_id": session_id,
                "response": "I apologize, but I encountered an error processing your request. Please try again."
            }
    
    def get_conversation_history(
        self,
        session_id: str
    ) -> List[Dict[str, str]]:
        """
        Get conversation history for a session.
        
        Args:
            session_id: The session ID
            
        Returns:
            List of message dictionaries
        """
        session = self.session_manager.get_session(session_id)
        if session:
            return [
                {"role": msg.role, "content": msg.content}
                for msg in session.get_conversation_history()
            ]
        return []
    
    def clear_session(self, session_id: str) -> bool:
        """
        Clear a specific session.
        
        Args:
            session_id: The session ID
            
        Returns:
            True if cleared successfully
        """
        session = self.session_manager.get_session(session_id)
        if session:
            session.clear()
            return True
        return False
    
    def validate_api_connection(self) -> bool:
        """
        Validate the Gemini API connection.
        
        Returns:
            True if connection is valid
        """
        try:
            return self.gemini_client.validate_api_key()
        except Exception as e:
            logger.error(f"API validation failed: {e}")
            return False


# Global instance
_career_advisor: Optional[CareerAdvisor] = None


def get_career_advisor() -> CareerAdvisor:
    """
    Get the global CareerAdvisor instance.
    
    Returns:
        The CareerAdvisor instance
    """
    global _career_advisor
    if _career_advisor is None:
        _career_advisor = CareerAdvisor()
    return _career_advisor
