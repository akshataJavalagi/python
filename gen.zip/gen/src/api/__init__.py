"""
API module for Career Advisor Chatbot.
Handles external API integrations.
"""

from src.api.gemini_client import GeminiClient, GeminiResponse

__all__ = ['GeminiClient', 'GeminiResponse']
