"""
Gemini API client for Career Advisor Chatbot.
Handles API requests, responses, and error handling.
"""

import os
from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from datetime import datetime

import google.generativeai as genai
from loguru import logger

from src.config.settings import get_settings


@dataclass
class GeminiResponse:
    """Data class for Gemini API response."""
    text: str
    model: str
    prompt_token_count: int
    candidate_token_count: int
    timestamp: datetime
    raw_response: Optional[Any] = None


class GeminiClient:
    """
    Client for Google Gemini Generative AI API.
    Handles API integration with proper error handling and logging.
    """
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize the Gemini client.
        
        Args:
            api_key: Optional API key. If not provided, will use environment variable.
        """
        settings = get_settings()
        self.api_key = api_key or settings.gemini_api_key or os.getenv("GEMINI_API_KEY")
        
        if not self.api_key:
            raise ValueError(
                "GEMINI_API_KEY is not set. Please set it in .env file or pass it directly."
            )
        
        # Configure the Gemini API
        genai.configure(api_key=self.api_key)
        
        # Load model configuration
        self.model_name = settings.api.gemini.model_name if settings.api else "gemini-pro"
        self.temperature = settings.api.gemini.temperature if settings.api else 0.7
        self.max_tokens = settings.api.gemini.max_tokens if settings.api else 2048
        self.top_p = settings.api.gemini.top_p if settings.api else 0.95
        self.top_k = settings.api.gemini.top_k if settings.api else 40
        
        # Initialize the model
        self._model = None
        self._initialize_model()
        
        logger.info(f"GeminiClient initialized with model: {self.model_name}")
    
    def _initialize_model(self) -> None:
        """Initialize the Gemini model with configuration."""
        try:
            generation_config = {
                "temperature": self.temperature,
                "top_p": self.top_p,
                "top_k": self.top_k,
                "max_output_tokens": self.max_tokens,
            }
            
            self._model = genai.GenerativeModel(
                model_name=self.model_name,
                generation_config=generation_config
            )
            
            logger.info("Gemini model initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize Gemini model: {e}")
            raise
    
    def generate_content(
        self,
        prompt: str,
        system_prompt: Optional[str] = None
    ) -> GeminiResponse:
        """
        Generate content using the Gemini API.
        
        Args:
            prompt: The user prompt/message
            system_prompt: Optional system prompt for context
            
        Returns:
            GeminiResponse object with the generated content
            
        Raises:
            Exception: If API call fails
        """
        try:
            # Build the full prompt
            if system_prompt:
                full_prompt = f"{system_prompt}\n\nUser: {prompt}"
            else:
                full_prompt = prompt
            
            logger.info(f"Generating content with model {self.model_name}")
            logger.debug(f"Prompt length: {len(full_prompt)} characters")
            
            # Generate content
            response = self._model.generate_content(full_prompt)
            
            # Extract response data
            result = GeminiResponse(
                text=response.text,
                model=self.model_name,
                prompt_token_count=response.usage_metadata.prompt_token_count,
                candidate_token_count=response.usage_metadata.candidates_token_count,
                timestamp=datetime.now(),
                raw_response=response
            )
            
            logger.info(
                f"Content generated successfully. "
                f"Prompt tokens: {result.prompt_token_count}, "
                f"Candidate tokens: {result.candidate_token_count}"
            )
            
            return result
            
        except Exception as e:
            logger.error(f"Error generating content: {e}")
            raise
    
    def generate_chat_response(
        self,
        messages: List[Dict[str, str]],
        system_prompt: Optional[str] = None
    ) -> GeminiResponse:
        """
        Generate a response for a multi-turn conversation.
        
        Args:
            messages: List of message dictionaries with 'role' and 'content'
            system_prompt: Optional system prompt
            
        Returns:
            GeminiResponse object with the generated content
        """
        try:
            # Start a chat session
            chat = self._model.start_chat(history=[])
            
            # Build conversation context
            if system_prompt:
                # Send system prompt first
                chat.send_message(system_prompt)
            
            # Send all previous messages except the last one
            for message in messages[:-1]:
                role = message.get("role", "user")
                content = message.get("content", "")
                
                if role == "model":
                    # For model responses, we need to handle differently
                    # Gemini chat uses user/model history
                    pass
                else:
                    chat.send_message(content)
            
            # Get response to the last message
            last_message = messages[-1].get("content", "") if messages else ""
            response = chat.send_message(last_message)
            
            result = GeminiResponse(
                text=response.text,
                model=self.model_name,
                prompt_token_count=response.usage_metadata.prompt_token_count,
                candidate_token_count=response.usage_metadata.candidates_token_count,
                timestamp=datetime.now(),
                raw_response=response
            )
            
            logger.info(f"Chat response generated successfully")
            return result
            
        except Exception as e:
            logger.error(f"Error generating chat response: {e}")
            raise
    
    def validate_api_key(self) -> bool:
        """
        Validate if the API key is valid.
        
        Returns:
            True if API key is valid, False otherwise
        """
        try:
            # Try to list models to validate the API key
            genai.list_models()
            logger.info("API key validated successfully")
            return True
        except Exception as e:
            logger.error(f"API key validation failed: {e}")
            return False
    
    def get_available_models(self) -> List[str]:
        """
        Get list of available models.
        
        Returns:
            List of model names
        """
        try:
            models = genai.list_models()
            return [m.name for m in models if 'generateContent' in m.supported_generation_methods]
        except Exception as e:
            logger.error(f"Error fetching models: {e}")
            return []
    
    def update_temperature(self, temperature: float) -> None:
        """
        Update the temperature parameter for generation.
        
        Args:
            temperature: New temperature value (0.0 to 1.0)
        """
        self.temperature = max(0.0, min(1.0, temperature))
        self._initialize_model()
        logger.info(f"Temperature updated to {self.temperature}")
    
    def update_max_tokens(self, max_tokens: int) -> None:
        """
        Update the max tokens parameter for generation.
        
        Args:
            max_tokens: New max tokens value
        """
        self.max_tokens = max_tokens
        self._initialize_model()
        logger.info(f"Max tokens updated to {self.max_tokens}")


def create_gemini_client(api_key: Optional[str] = None) -> GeminiClient:
    """
    Factory function to create a Gemini client.
    
    Args:
        api_key: Optional API key
        
    Returns:
        GeminiClient instance
    """
    return GeminiClient(api_key=api_key)
