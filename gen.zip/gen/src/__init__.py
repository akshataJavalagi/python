"""
Career Advisor Chatbot - Source Package
"""

__version__ = "1.0.0"
__author__ = "Your Name"

from src.config import get_settings
from src.api import GeminiClient
from src.domain import get_career_advisor

__all__ = ['get_settings', 'GeminiClient', 'get_career_advisor']
