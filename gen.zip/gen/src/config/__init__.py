"""
Configuration module for Career Advisor Chatbot.
Handles application settings and configuration management.
"""

from src.config.settings import Settings, get_settings

__all__ = ['Settings', 'get_settings']
