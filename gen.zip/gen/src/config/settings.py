"""
Settings management for Career Advisor Chatbot.
Loads configuration from config.yaml and environment variables.
"""

import os
from pathlib import Path
from typing import Optional
from functools import lru_cache

import yaml
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings


class ApplicationConfig(BaseModel):
    """Application configuration."""
    name: str = "Career Advisor Chatbot"
    version: str = "1.0.0"
    environment: str = "development"


class GeminiConfig(BaseModel):
    """Gemini API configuration."""
    model_name: str = "gemini-pro"
    temperature: float = 0.7
    max_tokens: int = 2048
    top_p: float = 0.95
    top_k: int = 40


class SessionConfig(BaseModel):
    """Session configuration."""
    max_conversation_turns: int = 10
    timeout_minutes: int = 30


class UIConfig(BaseModel):
    """UI configuration."""
    page_title: str = "Career Advisor Chatbot"
    page_icon: str = "💼"
    layout: str = "wide"
    initial_message: str = "Hello! I'm your Career Advisor Assistant. How can I help you today?"


class PromptConfig(BaseModel):
    """Prompt configuration."""
    system_prompt_template: str = ""
    user_prompt_template: str = ""


class APIConfig(BaseModel):
    """API configuration."""
    gemini: GeminiConfig = GeminiConfig()


class Settings(BaseSettings):
    """
    Main settings class that loads from both config.yaml and environment variables.
    Environment variables take precedence over config.yaml values.
    """
    
    # Application settings
    app_name: str = Field(default="Career Advisor Chatbot", alias="APP_NAME")
    app_version: str = Field(default="1.0.0", alias="APP_VERSION")
    environment: str = Field(default="development", alias="ENVIRONMENT")
    
    # API settings
    gemini_api_key: str = Field(default="", alias="GEMINI_API_KEY")
    model_name: str = Field(default="gemini-pro", alias="MODEL_NAME")
    temperature: float = Field(default=0.7, alias="TEMPERATURE")
    max_tokens: int = Field(default=2048, alias="MAX_TOKENS")
    
    # Session settings
    max_conversation_turns: int = Field(default=10, alias="MAX_CONVERSATION_TURNS")
    session_timeout_minutes: int = Field(default=30, alias="SESSION_TIMEOUT_MINUTES")
    
    # Configuration from YAML
    application: Optional[ApplicationConfig] = None
    api: Optional[APIConfig] = None
    session: Optional[SessionConfig] = None
    ui: Optional[UIConfig] = None
    prompts: Optional[PromptConfig] = None
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False
        extra = "ignore"


def load_yaml_config(config_path: str = "config.yaml") -> dict:
    """Load configuration from YAML file."""
    try:
        path = Path(config_path)
        if path.exists():
            with open(path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f) or {}
    except Exception as e:
        print(f"Warning: Could not load config.yaml: {e}")
    return {}


@lru_cache()
def get_settings() -> Settings:
    """
    Get cached settings instance.
    Loads configuration from both config.yaml and environment variables.
    """
    # Load YAML configuration
    yaml_config = load_yaml_config()
    
    # Create settings with YAML defaults
    settings = Settings(
        app_name=yaml_config.get('application', {}).get('name', 'Career Advisor Chatbot'),
        app_version=yaml_config.get('application', {}).get('version', '1.0.0'),
        environment=yaml_config.get('application', {}).get('environment', 'development'),
    )
    
    # Update with YAML config for nested objects
    if 'api' in yaml_config and 'gemini' in yaml_config['api']:
        settings.api = APIConfig(gemini=GeminiConfig(**yaml_config['api']['gemini']))
    
    if 'session' in yaml_config:
        settings.session = SessionConfig(**yaml_config['session'])
    
    if 'ui' in yaml_config:
        settings.ui = UIConfig(**yaml_config['ui'])
    
    if 'prompts' in yaml_config:
        settings.prompts = PromptConfig(**yaml_config['prompts'])
    
    settings.application = ApplicationConfig(**yaml_config.get('application', {}))
    
    return settings
