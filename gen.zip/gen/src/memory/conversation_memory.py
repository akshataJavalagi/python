"""
Conversation Memory for Career Advisor Chatbot.
Manages chat history, session state, and context preservation.
"""

import uuid
from typing import List, Optional, Dict, Any
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from collections import defaultdict

from loguru import logger

from src.config.settings import get_settings


@dataclass
class ConversationMessage:
    """Represents a single message in the conversation."""
    role: str  # "user" or "assistant"
    content: str
    timestamp: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, str]:
        """Convert to dictionary format."""
        return {
            "role": self.role,
            "content": self.content
        }


class ConversationMemory:
    """
    Manages conversation history for a single session.
    Maintains context across multiple turns.
    """
    
    def __init__(self, max_turns: Optional[int] = None):
        """
        Initialize conversation memory.
        
        Args:
            max_turns: Maximum number of conversation turns to remember
        """
        settings = get_settings()
        self.max_turns = max_turns or settings.session.max_conversation_turns
        self.messages: List[ConversationMessage] = []
        
        logger.debug(f"ConversationMemory initialized with max_turns: {self.max_turns}")
    
    def add_user_message(self, content: str) -> None:
        """
        Add a user message to the conversation.
        
        Args:
            content: The user's message content
        """
        message = ConversationMessage(role="user", content=content)
        self.messages.append(message)
        self._trim_history()
        logger.debug(f"Added user message. Total messages: {len(self.messages)}")
    
    def add_assistant_message(self, content: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        """
        Add an assistant (AI) message to the conversation.
        
        Args:
            content: The assistant's response content
            metadata: Optional metadata about the response
        """
        message = ConversationMessage(
            role="assistant",
            content=content,
            metadata=metadata or {}
        )
        self.messages.append(message)
        self._trim_history()
        logger.debug(f"Added assistant message. Total messages: {len(self.messages)}")
    
    def _trim_history(self) -> None:
        """Trim conversation history to max_turns."""
        if len(self.messages) > self.max_turns * 2:  # *2 for user+assistant pairs
            self.messages = self.messages[-(self.max_turns * 2):]
            logger.debug(f"Trimmed conversation history to {self.max_turns * 2} messages")
    
    def get_conversation_history(self) -> List[ConversationMessage]:
        """
        Get all conversation messages.
        
        Returns:
            List of ConversationMessage objects
        """
        return self.messages.copy()
    
    def get_recent_messages(self, count: int) -> List[ConversationMessage]:
        """
        Get the most recent N messages.
        
        Args:
            count: Number of recent messages to retrieve
            
        Returns:
            List of recent ConversationMessage objects
        """
        return self.messages[-count:] if self.messages else []
    
    def get_messages_for_api(self) -> List[Dict[str, str]]:
        """
        Get messages in format suitable for API calls.
        
        Returns:
            List of message dictionaries
        """
        return [msg.to_dict() for msg in self.messages]
    
    def get_context_string(self) -> str:
        """
        Get conversation history as a formatted string.
        
        Returns:
            Formatted conversation history string
        """
        if not self.messages:
            return ""
        
        lines = []
        for msg in self.messages:
            role = "User" if msg.role == "user" else "Assistant"
            lines.append(f"{role}: {msg.content}")
        
        return "\n".join(lines)
    
    def clear(self) -> None:
        """Clear all conversation history."""
        self.messages.clear()
        logger.info("Conversation history cleared")
    
    def get_message_count(self) -> int:
        """
        Get the total number of messages.
        
        Returns:
            Number of messages in the conversation
        """
        return len(self.messages)
    
    def get_turn_count(self) -> int:
        """
        Get the number of conversation turns (user + assistant pairs).
        
        Returns:
            Number of turns
        """
        return len(self.messages) // 2


class SessionManager:
    """
    Manages multiple conversation sessions.
    Handles session creation, retrieval, and cleanup.
    """
    
    def __init__(self):
        """Initialize the session manager."""
        self.sessions: Dict[str, ConversationMemory] = {}
        self.session_timestamps: Dict[str, datetime] = {}
        self.settings = get_settings()
        
        logger.info("SessionManager initialized")
    
    def create_session(self) -> str:
        """
        Create a new session.
        
        Returns:
            Session ID
        """
        session_id = str(uuid.uuid4())
        self.sessions[session_id] = ConversationMemory()
        self.session_timestamps[session_id] = datetime.now()
        
        logger.info(f"Created new session: {session_id}")
        return session_id
    
    def get_session(self, session_id: str) -> Optional[ConversationMemory]:
        """
        Get an existing session by ID.
        
        Args:
            session_id: The session ID
            
        Returns:
            ConversationMemory for the session, or None if not found
        """
        # Check if session exists and hasn't expired
        if session_id in self.sessions:
            if self._is_session_expired(session_id):
                logger.info(f"Session {session_id} expired, creating new one")
                self.delete_session(session_id)
                return self.create_new_session(session_id)
            return self.sessions[session_id]
        
        logger.warning(f"Session {session_id} not found")
        return None
    
    def _is_session_expired(self, session_id: str) -> bool:
        """
        Check if a session has expired.
        
        Args:
            session_id: The session ID
            
        Returns:
            True if expired, False otherwise
        """
        if session_id not in self.session_timestamps:
            return True
        
        timestamp = self.session_timestamps[session_id]
        expiry_time = timestamp + timedelta(minutes=self.settings.session.timeout_minutes)
        
        return datetime.now() > expiry_time
    
    def create_new_session(self, session_id: str) -> ConversationMemory:
        """
        Create a new session with the given ID.
        
        Args:
            session_id: The session ID
            
        Returns:
            New ConversationMemory instance
        """
        self.sessions[session_id] = ConversationMemory()
        self.session_timestamps[session_id] = datetime.now()
        
        logger.info(f"Created new session with ID: {session_id}")
        return self.sessions[session_id]
    
    def delete_session(self, session_id: str) -> bool:
        """
        Delete a session.
        
        Args:
            session_id: The session ID
            
        Returns:
            True if deleted, False if not found
        """
        if session_id in self.sessions:
            del self.sessions[session_id]
            del self.session_timestamps[session_id]
            logger.info(f"Deleted session: {session_id}")
            return True
        
        return False
    
    def cleanup_expired_sessions(self) -> int:
        """
        Clean up all expired sessions.
        
        Returns:
            Number of sessions cleaned up
        """
        expired_sessions = [
            sid for sid in self.sessions.keys()
            if self._is_session_expired(sid)
        ]
        
        for session_id in expired_sessions:
            self.delete_session(session_id)
        
        if expired_sessions:
            logger.info(f"Cleaned up {len(expired_sessions)} expired sessions")
        
        return len(expired_sessions)
    
    def get_active_session_count(self) -> int:
        """
        Get the number of active sessions.
        
        Returns:
            Number of active sessions
        """
        return len(self.sessions)


# Global session manager instance
_session_manager: Optional[SessionManager] = None


def get_session_manager() -> SessionManager:
    """
    Get the global SessionManager instance.
    
    Returns:
        The SessionManager instance
    """
    global _session_manager
    if _session_manager is None:
        _session_manager = SessionManager()
    return _session_manager
