"""
Prompt Manager for Career Advisor Chatbot.
Manages prompt templates, system prompts, and prompt engineering.
"""

from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime

from loguru import logger

from src.config.settings import get_settings


@dataclass
class PromptTemplate:
    """Represents a prompt template."""
    name: str
    template: str
    description: str = ""
    variables: List[str] = field(default_factory=list)
    
    def format(self, **kwargs) -> str:
        """Format the template with provided variables."""
        try:
            return self.template.format(**kwargs)
        except KeyError as e:
            logger.warning(f"Missing variable in prompt template: {e}")
            return self.template


@dataclass
class ConversationMessage:
    """Represents a single conversation message."""
    role: str  # "user", "assistant", or "system"
    content: str
    timestamp: datetime = field(default_factory=datetime.now)


class PromptManager:
    """
    Manages prompt templates and conversation context.
    Handles prompt engineering and formatting for the Career Advisor domain.
    """
    
    # Default system prompt for Career Advisor
    DEFAULT_SYSTEM_PROMPT = """You are an expert Career Advisor Assistant with extensive knowledge in:
- Career planning and development
- Resume writing and optimization
- Interview preparation
- Skill assessment and development
- Job search strategies
- Career transitions
- Professional networking

Your characteristics:
- Provide practical, actionable advice
- Ask clarifying questions to understand the user's situation better
- Be supportive, encouraging, and professional
- Base recommendations on the user's skills, experience, and goals
- Provide specific examples and resources when possible
- Maintain confidentiality and ethical standards

Always respond in a helpful, professional manner while being friendly and approachable."""
    
    def __init__(self):
        """Initialize the prompt manager."""
        self.settings = get_settings()
        self._templates: Dict[str, PromptTemplate] = {}
        self._initialize_default_templates()
        
        logger.info("PromptManager initialized")
    
    def _initialize_default_templates(self) -> None:
        """Initialize default prompt templates."""
        
        # Career advice template
        self._templates["career_advice"] = PromptTemplate(
            name="career_advice",
            template=self.DEFAULT_SYSTEM_PROMPT + "\n\nUser's Question: {user_message}\n\nPlease provide helpful career guidance.",
            description="Template for general career advice queries",
            variables=["user_message"]
        )
        
        # Resume review template
        self._templates["resume_review"] = PromptTemplate(
            name="resume_review",
            template=self.DEFAULT_SYSTEM_PROMPT + "\n\nPlease review the following resume and provide feedback:\n\n{resume_content}\n\nFocus on: Structure, Content, Keywords, Formatting, and Improvement suggestions.",
            description="Template for resume review requests",
            variables=["resume_content"]
        )
        
        # Interview preparation template
        self._templates["interview_prep"] = PromptTemplate(
            name="interview_prep",
            template=self.DEFAULT_SYSTEM_PROMPT + "\n\nHelp me prepare for an interview for the position of {job_title}.\n\nMy background: {background}\n\nPlease provide:\n1. Common interview questions\n2. Tips for answering behavioral questions\n3. Questions to ask the interviewer\n4. Any specific advice for this role",
            description="Template for interview preparation",
            variables=["job_title", "background"]
        )
        
        # Skill development template
        self._templates["skill_development"] = PromptTemplate(
            name="skill_development",
            template=self.DEFAULT_SYSTEM_PROMPT + "\n\nI want to develop skills in {skill_area}.\n\nMy current level: {current_level}\n\nMy goal: {learning_goal}\n\nPlease provide a learning path with:\n1. Recommended resources\n2. Practice exercises\n3. Timeline suggestions\n4. Ways to demonstrate proficiency",
            description="Template for skill development guidance",
            variables=["skill_area", "current_level", "learning_goal"]
        )
        
        # Job search strategy template
        self._templates["job_search"] = PromptTemplate(
            name="job_search",
            template=self.DEFAULT_SYSTEM_PROMPT + "\n\nI'm looking for a job in {industry} with focus on {role}.\n\nMy experience: {experience}\n\nPlease help me create a job search strategy including:\n1. Best job boards and resources\n2. Networking strategies\n3. Application tips\n4. Companies to target",
            description="Template for job search strategy",
            variables=["industry", "role", "experience"]
        )
        
        # Load custom templates from config if available
        if self.settings.prompts and self.settings.prompts.system_prompt_template:
            self._templates["custom_system"] = PromptTemplate(
                name="custom_system",
                template=self.settings.prompts.system_prompt_template,
                description="Custom system prompt from config",
                variables=[]
            )
    
    def get_system_prompt(self) -> str:
        """
        Get the current system prompt.
        
        Returns:
            The system prompt string
        """
        if (self.settings.prompts and 
            self.settings.prompts.system_prompt_template):
            return self.settings.prompts.system_prompt_template
        
        return self.DEFAULT_SYSTEM_PROMPT
    
    def get_user_prompt(
        self,
        user_message: str,
        conversation_history: Optional[List[ConversationMessage]] = None
    ) -> str:
        """
        Build a user prompt with conversation context.
        
        Args:
            user_message: The current user message
            conversation_history: Optional list of previous messages
            
        Returns:
            Formatted user prompt
        """
        # Build conversation history string
        history_str = ""
        if conversation_history:
            history_lines = []
            for msg in conversation_history[-self.settings.session.max_conversation_turns:]:
                role = "User" if msg.role == "user" else "Assistant"
                history_lines.append(f"{role}: {msg.content}")
            
            if history_lines:
                history_str = "\n".join(history_lines)
        
        # Format the prompt
        if history_str:
            prompt = f"""Previous Conversation:
{history_str}

Current User Message: {user_message}

Please provide a helpful response based on the conversation history and the current message."""
        else:
            prompt = user_message
        
        return prompt
    
    def get_template(self, template_name: str) -> Optional[PromptTemplate]:
        """
        Get a specific prompt template by name.
        
        Args:
            template_name: Name of the template
            
        Returns:
            PromptTemplate if found, None otherwise
        """
        return self._templates.get(template_name)
    
    def format_template(self, template_name: str, **kwargs) -> str:
        """
        Format a specific template with provided variables.
        
        Args:
            template_name: Name of the template
            **kwargs: Variables to fill in the template
            
        Returns:
            Formatted prompt string
        """
        template = self.get_template(template_name)
        if template:
            return template.format(**kwargs)
        
        logger.warning(f"Template '{template_name}' not found")
        return kwargs.get("user_message", "")
    
    def add_template(self, template: PromptTemplate) -> None:
        """
        Add a new prompt template.
        
        Args:
            template: The PromptTemplate to add
        """
        self._templates[template.name] = template
        logger.info(f"Added new prompt template: {template.name}")
    
    def list_templates(self) -> List[str]:
        """
        Get list of all available template names.
        
        Returns:
            List of template names
        """
        return list(self._templates.keys())
    
    def build_full_prompt(
        self,
        user_message: str,
        conversation_history: Optional[List[ConversationMessage]] = None,
        template_name: Optional[str] = None
    ) -> tuple[str, str]:
        """
        Build a complete prompt with system and user messages.
        
        Args:
            user_message: The user's message
            conversation_history: Optional conversation history
            template_name: Optional specific template to use
            
        Returns:
            Tuple of (system_prompt, user_prompt)
        """
        system_prompt = self.get_system_prompt()
        
        if template_name:
            user_prompt = self.format_template(template_name, user_message=user_message)
        else:
            user_prompt = self.get_user_prompt(user_message, conversation_history)
        
        return system_prompt, user_prompt


# Global instance
_prompt_manager: Optional[PromptManager] = None


def get_prompt_manager() -> PromptManager:
    """
    Get the global PromptManager instance.
    
    Returns:
        The PromptManager instance
    """
    global _prompt_manager
    if _prompt_manager is None:
        _prompt_manager = PromptManager()
    return _prompt_manager
