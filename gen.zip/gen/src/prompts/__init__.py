"""
Prompts module for Career Advisor Chatbot.
Manages prompt templates and configurations.
"""

from src.prompts.prompt_manager import PromptManager, get_prompt_manager

__all__ = ['PromptManager', 'get_prompt_manager']
