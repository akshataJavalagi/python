"""
Streamlit UI for Career Advisor Chatbot.
Provides an interactive chat interface.
"""

import os
import sys
from typing import Optional

import streamlit as st
from loguru import logger

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.config.settings import get_settings
from src.domain.career_advisor import CareerAdvisor, get_career_advisor


def setup_logging():
    """Setup logging for the application."""
    logger.remove()
    logger.add(
        sys.stderr,
        format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <level>{message}</level>",
        level="INFO"
    )


def initialize_session_state():
    """
    Initialize Streamlit session state variables.
    """
    settings = get_settings()
    
    if 'session_id' not in st.session_state:
        st.session_state.session_id = None
    
    if 'messages' not in st.session_state:
        st.session_state.messages = []
    
    if 'career_advisor' not in st.session_state:
        try:
            st.session_state.career_advisor = get_career_advisor()
        except Exception as e:
            logger.error(f"Failed to initialize CareerAdvisor: {e}")
            st.session_state.career_advisor = None
    
    if 'api_configured' not in st.session_state:
        api_key = os.getenv("GEMINI_API_KEY") or settings.gemini_api_key
        st.session_state.api_configured = bool(api_key)
    
    if 'initialized' not in st.session_state:
        st.session_state.initialized = True


def render_header():
    """Render the application header."""
    settings = get_settings()
    
    st.set_page_config(
        page_title=settings.ui.page_title if settings.ui else "Career Advisor Chatbot",
        page_icon=settings.ui.page_icon if settings.ui else "💼",
        layout="wide" if (settings.ui and settings.ui.layout == "wide") else "centered"
    )
    
    # Custom CSS for better styling
    st.markdown("""
        <style>
        .main {
            background-color: #f5f5f5;
        }
        .stChatMessage {
            background-color: white;
            border-radius: 10px;
            padding: 15px;
            margin: 10px 0;
        }
        .user-message {
            background-color: #e3f2fd;
            border-left: 4px solid #2196f3;
        }
        .assistant-message {
            background-color: #f1f8e9;
            border-left: 4px solid #4caf50;
        }
        .title {
            text-align: center;
            color: #1a237e;
            font-size: 2.5em;
            margin-bottom: 0.5em;
        }
        .subtitle {
            text-align: center;
            color: #455a64;
            font-size: 1.2em;
            margin-bottom: 2em;
        }
        .success-box {
            padding: 15px;
            background-color: #d4edda;
            border: 1px solid #c3e6cb;
            border-radius: 5px;
            color: #155724;
            margin: 10px 0;
        }
        .error-box {
            padding: 15px;
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            border-radius: 5px;
            color: #721c24;
            margin: 10px 0;
        }
        </style>
    """, unsafe_allow_html=True)
    
    # Header
    st.markdown('<p class="title">💼 Career Advisor Chatbot</p>', unsafe_allow_html=True)
    st.markdown('<p class="subtitle">Your AI-Powered Career Guidance Assistant</p>', unsafe_allow_html=True)


def render_api_key_config():
    """Render API key configuration section."""
    st.sidebar.title("⚙️ API Configuration")
    
    api_key = st.sidebar.text_input(
        "Gemini API Key",
        type="password",
        help="Enter your Google Gemini API key"
    )
    
    if api_key:
        os.environ["GEMINI_API_KEY"] = api_key
        st.session_state.api_configured = True
        st.sidebar.success("✅ API Key configured!")
        
        # Re-initialize CareerAdvisor if it wasn't initialized
        if st.session_state.career_advisor is None:
            try:
                st.session_state.career_advisor = get_career_advisor()
            except Exception as e:
                logger.error(f"Failed to initialize CareerAdvisor: {e}")
                st.session_state.career_advisor = None
    
    if not st.session_state.get('api_configured'):
        st.sidebar.warning("⚠️ Please enter your Gemini API Key")
        
        st.info("""
        **To get a Gemini API Key:**
        1. Go to [Google AI Studio](https://makersuite.google.com/app/apikey)
        2. Create a new API key
        3. Enter the key in the sidebar
        """)
        return False
    
    return True


def render_sidebar():
    """Render the sidebar with options."""
    st.sidebar.title("📋 Options")
    
    # Clear conversation
    if st.sidebar.button("🗑️ Clear Conversation"):
        if st.session_state.session_id and st.session_state.career_advisor:
            st.session_state.career_advisor.clear_session(st.session_state.session_id)
        st.session_state.messages = []
        st.session_state.session_id = None
        st.rerun()
    
    # Session info
    if st.session_state.session_id:
        st.sidebar.markdown(f"**Session ID:** `{st.session_state.session_id[:8]}...`")
    
    # About section
    st.sidebar.markdown("---")
    st.sidebar.markdown("### About")
    st.sidebar.markdown("""
    This Career Advisor Chatbot uses Google Gemini AI to provide:
    - Career guidance and planning
    - Resume reviews
    - Interview preparation
    - Skill development advice
    - Job search strategies
    """)
    
    st.sidebar.markdown("---")
    st.sidebar.markdown("### Tips")
    st.sidebar.markdown("""
    - Be specific about your career goals
    - Share relevant background information
    - Ask follow-up questions for details
    - Use the template shortcuts below
    """)


def render_template_buttons():
    """Render quick template buttons."""
    st.markdown("### Quick Templates")
    
    col1, col2, col3, col4 = st.columns(4)
    
    templates = {
        "Resume Review": "Please review my resume and provide feedback on structure, content, and improvements.",
        "Interview Prep": "Help me prepare for a job interview. The position is [Your Position].",
        "Skill Development": "I want to develop skills in [Skill Area]. What's a good learning path?",
        "Job Search": "Help me create a job search strategy for [Industry/Role]."
    }
    
    for i, (label, template) in enumerate(templates.items()):
        if i == 0:
            if col1.button(label):
                st.session_state.Quick_template = template
                st.rerun()
        elif i == 1:
            if col2.button(label):
                st.session_state.Quick_template = template
                st.rerun()
        elif i == 2:
            if col3.button(label):
                st.session_state.Quick_template = template
                st.rerun()
        elif i == 3:
            if col4.button(label):
                st.session_state.Quick_template = template
                st.rerun()


def render_chat_messages():
    """Render the chat message history."""
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
            
            # Show metadata for assistant messages
            if message["role"] == "assistant" and "metadata" in message:
                metadata = message["metadata"]
                with st.expander("Response Details"):
                    st.write(f"**Query Type:** {metadata.get('query_type', 'N/A')}")
                    st.write(f"**Prompt Tokens:** {metadata.get('prompt_tokens', 'N/A')}")
                    st.write(f"**Response Tokens:** {metadata.get('candidate_tokens', 'N/A')}")


def handle_user_input(user_input: str) -> None:
    """
    Process user input and get AI response.
    
    Args:
        user_input: The user's message
    """
    if not user_input.strip():
        return
    
    # Add user message to display
    st.session_state.messages.append({
        "role": "user",
        "content": user_input
    })
    
    # Display user message
    with st.chat_message("user"):
        st.markdown(user_input)
    
    # Get AI response
    with st.chat_message("assistant"):
        message_placeholder = st.empty()
        message_placeholder.markdown("🤔 Thinking...")
        
        try:
            # Call the career advisor
            result = st.session_state.career_advisor.chat(
                user_message=user_input,
                session_id=st.session_state.session_id
            )
            
            # Update session ID if new
            if not st.session_state.session_id and result.get('session_id'):
                st.session_state.session_id = result['session_id']
            
            if result.get('success'):
                response = result['response']
                message_placeholder.markdown(response)
                
                # Add to message history
                st.session_state.messages.append({
                    "role": "assistant",
                    "content": response,
                    "metadata": result.get('metadata', {})
                })
            else:
                error_msg = result.get('response', 'An error occurred')
                message_placeholder.markdown(f"❌ {error_msg}")
                
                st.session_state.messages.append({
                    "role": "assistant",
                    "content": error_msg,
                    "metadata": {"error": result.get('error')}
                })
                
        except Exception as e:
            logger.error(f"Error processing user input: {e}")
            error_msg = f"I apologize, but I encountered an error: {str(e)}"
            message_placeholder.markdown(f"❌ {error_msg}")
            
            st.session_state.messages.append({
                "role": "assistant",
                "content": error_msg,
                "metadata": {"error": str(e)}
            })


def render_initial_message():
    """Render the initial welcome message."""
    settings = get_settings()
    initial_msg = settings.ui.initial_message if settings.ui else "Hello! I'm your Career Advisor Assistant. How can I help you today?"
    
    st.markdown(f"""
    <div class="success-box">
        {initial_msg}
    </div>
    """, unsafe_allow_html=True)


def main():
    """Main application entry point."""
    # Setup
    setup_logging()
    initialize_session_state()
    
    # Render header
    render_header()
    
    # Check API configuration
    if not render_api_key_config():
        st.warning("Please configure your API key to start chatting!")
        return
    
    # Render sidebar
    render_sidebar()
    
    # Main content area
    st.markdown("---")
    
    # Quick templates
    with st.expander("📝 Quick Templates", expanded=False):
        render_template_buttons()
    
    # Chat container
    chat_container = st.container()
    
    with chat_container:
        # Render existing messages
        if not st.session_state.messages:
            render_initial_message()
        
        render_chat_messages()
        
        # Chat input
        user_input = st.chat_input(
            "Type your career question here...",
            key="chat_input"
        )
        
        # Handle quick template if selected
        if hasattr(st.session_state, 'Quick_template') and st.session_state.Quick_template:
            user_input = st.session_state.Quick_template
            del st.session_state.Quick_template
        
        # Process user input
        if user_input:
            handle_user_input(user_input)
            st.rerun()


if __name__ == "__main__":
    main()
